---
name: "tor-word-compliance-check"
description: "ตรวจ TOR/SOC ใน Word เทียบ Datasheet, Catalog, Product Brochure หรือหนังสือรับรอง PDF แล้วบันทึกผลลงสำเนา Word โหมดมาตรฐานตรวจหน้าอ้างอิง ชื่อหัวข้อ ยี่ห้อ/รุ่น และความเกี่ยวข้อง; Full audit เพิ่มเลขข้อและ Highlight; เปิด evidence_support เมื่อต้องตรวจว่าหลักฐานรองรับ TOR และเปิด tor_decision เมื่อต้องตัดสิน Comply/Better; ส่งตารางผลแยกจาก SOC เป็น Word หรือ Excel รายภาคผนวกได้"
---

# TOR/SOC Word Compliance Check

ส่งมอบสำเนา DOCX ที่มีผลตรวจรายข้อต่อท้าย ไม่แก้ Word ต้นฉบับ

## Modes และไฟล์ที่ต้องอ่าน

- `standard` (ค่าเริ่มต้น): `reference`, `heading_title`, `product_identity`, `content_relevance`
- `full_audit`: เพิ่ม `item_label`, `highlight` (เลือกเมื่อผู้ใช้พูดถึงเลขข้อ annotation Highlight สีเน้น หรือตรวจก่อนยื่นแบบครบ)
- `evidence_support` (option): ตรวจสาย TOR ↔ ข้อเสนอ ↔ หน้าที่อ้าง ↔ Highlight เมื่อผู้ใช้ถามว่าหลักฐานรองรับ TOR ไหม
- `tor_decision` (option): ตัดสิน `compliant`/`better`/`non_compliant`/`mixed`/`unverifiable`/`not_applicable` เมื่อผู้ใช้ขอผลผ่าน/ไม่ผ่าน/ดีกว่า ยืนยันช่อง Comply/Better หรือถามว่า SOC "ตรง TOR หรือยัง" ต้องเปิด `evidence_support` ด้วย
- `custom`: ประเมินเฉพาะ `checks` ที่ผู้ใช้ระบุ
- `evidence_packet` (option, **ปิดเป็นค่าเริ่มต้น**, ใช้กับ `full_audit` + SOC `.docx`): script เตรียมข้อเท็จจริงของทุกแถวแทนการเปิด PDF เอง กติกาเหมือนเดิม ผลเขียนเป็น Compact Results (หัวข้อ results.json) ถ้าไม่เปิด ห้ามรัน `build_evidence_packet.py`

**อ่านเฉพาะไฟล์ในตารางนี้** (ทุกตัวอักษรที่อ่านถูกส่งซ้ำทุก turn) ห้ามเปิด source ของ `scripts/*.py` เพื่อหา field หรือค่าที่ใช้ได้ ทุกอย่างอยู่ในหัวข้อ "results.json" ด้านล่าง เปิด source ได้เฉพาะเมื่อ script ล้มและข้อความ error ไม่พอ

| เมื่อ | อ่าน |
|---|---|
| ทุกครั้ง | SKILL.md (ไฟล์นี้) |
| เปิด `tor_decision` | [tor-decision.md](references/tor-decision.md) |
| เปิด `evidence_packet` | [evidence-packet.md](references/evidence-packet.md) |
| ไม่เปิด `evidence_packet` (เปิด PDF เอง) | [old-flow.md](references/old-flow.md) และเมื่อเปิด `item_label`/`highlight` [highlight-audit.md](references/highlight-audit.md) |
| TOR/หลักฐานคนละภาษา หรือหน้ามีตัวเลขหลายชนิด และไม่มี packet | [metric-matching.md](references/metric-matching.md) |
| ผู้ใช้ขอให้ชื่อหัวข้อตรง Datasheet คำต่อคำ | [check-rules.md](references/check-rules.md) |
| `append_results_to_docx.py`/validator ล้ม หรือมีผู้ใช้รอไฟล์ (render QA) | [word-output.md](references/word-output.md) |
| ผู้ใช้ขอตารางแยกจาก SOC (Word/Excel) หรือสรุปผลในแชต | [deliverables.md](references/deliverables.md) |

## Workflow

เมื่อเปิด `evidence_packet`: ขั้นที่ 0–6 ทำจาก packet ตาม evidence-packet.md แล้วกลับมาทำขั้นที่ 7–8 **ห้ามสรุป "ไม่พบ" (`not_found`, `mismatch`, `unrelated`, `not_supported` หรือ ❌) จาก packet อย่างเดียว**

0. **เอกสารที่ถูกอ้าง**: รวบรวมชื่อเอกสาร/Section ทุกรายการในคอลัมน์อ้างอิง เทียบกับไฟล์ที่ได้รับ เอกสารที่ถูกอ้างแต่ไม่มีไฟล์ตรงตัว ต้องแจ้งผู้ใช้ทันทีก่อนตรวจต่อ ห้ามปล่อยเป็น `unverifiable`/`not_found` เงียบ ๆ
   - **อ้างแค่โฟลเดอร์ที่มี PDF หลายไฟล์** (รวมโฟลเดอร์ย่อย): ตรวจต่อได้โดยไม่ต้องรอคำตอบ เลือกไฟล์ต่อแถวตามลำดับ (1) เลขโฟลเดอร์ย่อยตรงข้อย่อยของแถว (๑) → `1.…/`) (2) ป้ายเลขข้อของแถวอยู่บนหน้าที่อ้างในไฟล์เดียว (3) เนื้อหาหน้าที่อ้างตรง TOR/ข้อเสนอในไฟล์เดียว ใส่ `reference_file` ทุกแถว และเขียนวิธีเลือกใน `reference_detail` ถ้าตัดสินไม่ได้ = ⚠️ `key_issue` "อ้างอิงระบุแค่โฟลเดอร์ มีหลายไฟล์" พร้อมรายชื่อไฟล์ candidate ห้ามเลือกเงียบ ๆ
1. ระบุ Word ต้นฉบับและ PDF หลักฐาน `.doc` ให้แปลงเป็น `.docx` ไฟล์ใหม่ ห้ามแก้ต้นฉบับ
2. หา header ลำดับข้อ TOR ข้อเสนอ Comply/Better และเลขอ้างอิงจากโครงสร้างตารางจริง ห้ามสมมติ index คอลัมน์ (merged cells/checkbox: `scripts/inspect_word_table.py`)
3. จำแนกทุกแถวเป็น `product_identity_row` (ยี่ห้อ/รุ่น), `system_heading_row` (ชื่อระบบ/โมดูลที่จัดกลุ่มข้อย่อย), `content_row` (ความสามารถหรือค่าที่ต้องมีหลักฐาน) หรือ `section_heading_row` (หัวข้อล้วน ไม่มี claim) จากโครงสร้าง merge ร่วมกับข้อความ ไม่ใช่จากการมี/ไม่มีเลขหน้า
4. แยก printed page จาก PDF page ตรวจทุกหน้าที่อ้างแยกกัน หน้าไม่เกี่ยวข้องต้องไม่ถูกซ่อนด้วยหน้าอื่น ค้น candidate page เฉพาะ claim ที่ขาด ห้ามแก้อ้างอิงเอง
5. หน้า `low_text`/สแกน/คลุมเครือ ต้องดูภาพก่อนให้ `mismatch`/`unrelated`/`not_found` ความยาวข้อความต่ำไม่เท่ากับหน้าว่าง ช่อง SOC ว่างไม่ได้แปลว่าไม่มีอะไรให้เทียบ ต้องอ่านข้อความทั้งหน้าที่อ้างก่อน
6. ตัดสินแต่ละ check ตาม "ค่าของแต่ละ check" และ "Judgment rules" ด้านล่าง (และ tor-decision.md เมื่อเปิด) แถวที่เขียนว่า "ต้องตรวจภาพ/ตรวจเพิ่ม" ต้องทำจริงก่อนส่ง
7. เขียน results.json ชุดเดียวทุกแถว (packet: Compact Results แล้ว `expand_results.py`) แล้วรัน validator ครั้งเดียวกับ highlights ทุกไฟล์ จากนั้นรัน `append_results_to_docx.py` (หัวข้อ "results.json") **ห้ามเขียนสคริปต์ post-process เอง** สี สถานะย่อย และ "ควรตรวจซ้ำ" สคริปต์ใส่ให้แล้ว
8. QA: เปิดไฟล์ผลได้ ตาราง SOC เดิมไม่เปลี่ยน จำนวนแถวผลเท่า results ส่วนผลแนวนอน มีผู้ใช้รอไฟล์ให้ render ตาม word-output.md

## ค่าของแต่ละ check

- `reference_check`: `match` ทุกหน้าที่อ้างรวมกันรองรับ claim ครบ (ดูเนื้อหาเท่านั้น ไม่ดู Highlight/เลขข้อ); `mismatch` หน้าผิด หน้าเกิน หรือขาดหน้าจำเป็น (แจกแจงเลขหน้า; หน้าแรกของ DS ที่จำเป็นต่อการยืนยันรุ่นไม่นับเป็นหน้าเกิน); `not_found` ช่องอ้างอิงว่างในแถวที่ต้องมีหลักฐาน; `unverifiable` เปิดแล้วอ่านไม่ได้/ข้อมูลไม่พอหลังดูภาพ; `not_applicable` หัวข้อที่ไม่ต้องมีหลักฐาน
  - แยกข้อเสนอเป็น claim ย่อย (รุ่น ความสามารถ ตัวเลข หน่วย เงื่อนไข คำเชื่อม) ระบุว่าแต่ละหน้ารองรับ claim ใด บันทึก `reference_detail` ทุกแถว: หน้าที่ถูก หน้าเกิน/ผิด claim ที่ขาด และ candidate page
- `heading_title_check` (เฉพาะ `system_heading_row` อื่น ๆ `not_applicable`): ค่าเริ่มต้นเทียบตามความหมาย (Judgment rule 6) แบบคำต่อคำเฉพาะเมื่อผู้ใช้ขอ (check-rules.md)
- `product_identity` (เฉพาะ `product_identity_row`): `match`/`mismatch` (คนละยี่ห้อ/รุ่น → `content_relevance: unrelated` ด้วย)/`unverifiable` (ภาพ อ่านรุ่นไม่ได้) ไม่สืบทอดผลจากแถวอื่น
- `content_relevance`: `related`/`unrelated`/`unverifiable`
- `item_label_check`: `match`/`not_found`/`not_applicable` (เอกสารไม่ควรมีเลข TOR) ไม่พบหรือพบแค่เลขข้อแม่ = แจ้งเตือน (rule 3)
- `highlight_check`: `complete`/`partial_visible`/`partial`/`not_found`/`unverifiable`/`not_applicable` + `highlight_evidence` (rule 11)
- `evidence_support`: `fully_supported`/`partially_supported`/`not_supported`/`wording_conflict`/`unverifiable` + `evidence_detail` ว่า claim ใดรองรับหรือไม่ พร้อมหน้าและข้อความหลักฐาน ไม่แปลงเป็นผ่าน/ไม่ผ่าน คำเชื่อม (`and`, `or`, `at least`, `up to`) ตัวเลข และหน่วยต้องตรง
- `confidence`: ค่า `high`/`medium`/`low` คำเดียว (script เทียบตรงตัว) เหตุผลสั้น ("high เพราะ …") ใส่ใน `detail` ห้ามเป็นเปอร์เซ็นต์ (rule 2)

## Judgment rules

1. **ตัดสินตามความหมาย ไม่ใช่ตัวอักษร**: TOR ข้อเสนอ และหน้าที่อ้างต้องตรงในสาระ ถ้อยคำ/ภาษาที่ต่างไม่ลดผลหรือความเชื่อมั่น (TOR "ตรวจจับความเคลื่อนไหวอัตโนมัติ (Motion Detection)", ข้อเสนอ "Supports motion detection", DS "Motion Detection OFF/ON" = ตรง) ยกเว้นคำเชื่อม ตัวเลข หน่วย และเงื่อนไขที่เปลี่ยนความหมาย
2. **`confidence`**: `high` หน้าที่อ้างรองรับสิ่งที่ TOR และผู้เสนอต้องการโดยตรงแม้ถ้อยคำต่าง; `medium` เฉพาะเมื่ออนุมานหลายจุด ค่าที่ต้องคำนวณ จำนวนที่เป็น configuration ซึ่ง DS ไม่ระบุ หรือหลักฐานบางส่วน; `low` หลักฐานอ่านไม่ชัดหรือขัดกัน ไม่ใช่เหตุให้ลดเป็น `medium`: ถ้อยคำต่าง หลักฐานกระจายหลายแถวในหน้าเดียวกับที่อ้าง (ปัญหาเฉพาะเมื่อคนละหน้า) คำรับรองของผู้เสนอ (rule 5) เลขข้อกำกับไม่พบ (rule 3)
3. **เลขข้อกำกับไม่พบ หรือพบแค่เลขข้อแม่** (หน้ามี 3.4.1 แถวคือ 3.4.1.1): แจ้งเตือนเท่านั้น ระบุใน `item_label_check` และประเด็นหลัก (พร้อมเลขข้อแม่ที่พบ) **ห้ามลด `confidence` และห้ามเปลี่ยนผลของแถว** ถ้าเนื้อหารองรับ claim
4. **"หรือ" / "หรือดีกว่า"**: ทางเลือกใดทางเลือกหนึ่งครบก็ผ่าน "X หรือดีกว่า" ค่าที่ดีกว่าตามทิศของ metric = รองรับ มาตรฐานที่ไม่มีลำดับในตัว (IP66 กับ IP67) ให้ผลตามถ้อยคำ TOR + `confidence: medium` พร้อมหมายเหตุ
5. **คำรับรองของผู้เสนอที่ไม่อยู่ในเอกสารผู้ผลิต** ("ลิขสิทธิ์ถูกต้อง", "or later", "Manufacturer Certification") ไม่ลดความเชื่อมั่นของเนื้อหาหลักที่ DS ยืนยัน แต่หมายเหตุว่าต้องมีเอกสารแยกเมื่อจำเป็น (เช่นใบรับรอง ISO เมื่อหน้าอ้างเขียนแค่ "Comply with ISO 9001")
6. **แถวหัวข้อ/ชื่อรุ่น**: แถวหัวข้อผ่านและ `high` เมื่อสอดคล้องกับหัวข้อ/เนื้อหาในหน้าที่อ้าง เนื้อหาจริงตรวจที่ข้อย่อย ห้ามนำ claim ของข้อย่อยมาลดผล; แถวชื่อรุ่นตรวจว่ารุ่นอยู่บนหน้าที่อ้าง ตรง = `high` อยู่คนละหน้าหรือไม่ปรากฏ = แจ้งเตือน + candidate page (ห้ามแก้เลขหน้าเอง)
7. **ข้อความที่ SOC อ้างแต่ไม่มีใน DS ทั้งไฟล์**: หน้าที่อ้างเกี่ยวข้อง = `reference_check: match` แล้วสะท้อนช่องว่างที่ `evidence_support` (`partially_supported`/`not_supported`/`wording_conflict`) + `key_issue` ว่าขาดอะไร; `mismatch` เมื่อหลักฐานอยู่หน้าที่ไม่ได้อ้าง (ใส่ `candidate_reference`) หรืออ้างหน้าเกิน (อ้าง 18–19 แต่หลักฐานอยู่ 18); ช่องอ้างอิงว่างและไม่พบป้ายข้อ = `not_found` + `evidence_support: unverifiable`; หน้า drawing ที่มีป้ายเลขข้อแต่ไม่มี Highlight = `highlight_check: complete` + หมายเหตุ; แถวรูป = reference `match`, evidence `not_applicable`
8. **เมื่อแนะนำเพิ่มหลักฐาน**: ห้ามเสนอหน้า DS ของรุ่นอื่นแทน ให้ขอเอกสารของรุ่นนั้นจากผู้ผลิต และเมื่อแนะนำหน้าเพิ่ม บอกว่าหน้านั้นมีป้ายเลขข้อ/Highlight แล้วหรือยัง (ป้ายที่มีคือข้อใด)
9. **ข้ออ้างเรื่องสิทธิ์** (license/ลิขสิทธิ์ แต่งตั้ง/ตัวแทนจำหน่าย รับประกัน บริการ ศูนย์บริการ): ถ้าหน้าที่อ้างไม่รองรับ ก่อนตัดสิน**ต้อง list ทุกไฟล์นอกโฟลเดอร์ Datasheet** (ไม่ใช่ DS, SOC, TOR) แล้วเปิดหน้าแรกของไฟล์ที่ชื่อเข้าเค้า ระบุจากชื่อไฟล์และเนื้อหา ไม่ผูกกับเลขบท ห้ามจบที่ "ควรมีหนังสือรับรอง" กว้าง ๆ
   - พบ: ⚠️ `evidence_support: partially_supported` (`not_supported` ถ้าหน้าที่อ้างไม่รองรับเลย) `key_issue` = "ควรเพิ่มอ้างอิง <ชื่อไฟล์> (<ผู้ออก/สิ่งที่รับรอง>)"; ไม่พบ: ⚠️ "ไม่พบเอกสาร<สิ่งที่ต้องใช้> ในชุดหลักฐาน" ห้าม ❌
   - ตัวอย่าง ๑.๒ MOF_RFID แถว 92: TOR "มี Application License ที่รองรับการใช้งานร่วมกับ Software Asset Management…" อ้าง TC22 หน้า 2 (ไม่พูดถึง license) ชุดหลักฐานมี "ZPL2600054 Zebra Business Letter -หนังสือแต่งตั้งการเป็นตัวแทน-ICN (P).pdf" → ⚠️ "ควรเพิ่มอ้างอิง ZPL2600054 Zebra Business Letter (หนังสือแต่งตั้งตัวแทนจำหน่ายจาก Zebra)"
   - แถวอื่นที่ไม่อ้างหนังสือแต่งตั้ง**ไม่ใช่ข้อผิด** อย่างมากหมายเหตุเบา ๆ เมื่อแถวส่วนใหญ่ของข้อเดียวกันอ้างแต่บางแถวไม่อ้าง ห้าม ❌
10. **แถวหัวข้อย่อยที่ข้อเสนอคัดลอก TOR** (มีข้อย่อยอยู่ใต้ ข้อเสนอเท่ากับ TOR หลังรวมช่องว่าง): `item_label_check`/`highlight_check`/`product_identity` = `not_applicable` ห้ามพูดถึงสามเรื่องนี้ใน `key_issue` แต่**ยังต้องตรวจว่าหน้าที่อ้างตรงกับ TOR/ข้อเสนอ** ไม่มีอ้างอิงเลย = ✅ `reference_check: not_applicable` ตัวอย่างแถว 101 ๕.๕(๒) "อุปกรณ์เสริมสำหรับอ่าน RFID…" อ้าง "2.5 หน้า 1": RFD40 หน้า 1 (sled) = ✅ ไม่มีหมายเหตุเลขข้อ; ชี้ได้แค่ TC22 = ⚠️ สินค้าอื่น แนะนำ RFD40 หน้า 1; RFD40 หน้า 3 (spec ไม่บอกชนิด) = ⚠️ ไม่ยืนยันชนิดสินค้า; ไม่มีไฟล์ใดเป็นอุปกรณ์อ่าน RFID = ❌
11. **Highlight ไม่ครบแต่หลักฐานอยู่หน้าเดียวกัน** = `highlight_check: partial_visible` (ผ่าน สีเขียว) ไม่ใช่ `partial`: แถว content ที่ TOR มีหลายเงื่อนไข เทียบแต่ละเงื่อนไขกับข้อความ Highlight เงื่อนไขที่ไม่อยู่ใน Highlight ให้หาในข้อความทั้งหน้าที่อ้าง ถ้าเห็นชัดในแถวอื่นของหน้าเดียวกัน = `partial_visible` และเขียนใน `highlight_evidence` ว่าคำใดไม่ได้ Highlight เห็นที่แถวใด ห้ามใส่ใน `key_issue` และห้ามลด `confidence` (๑.๓ แถว 93: "สัมผัส" ไม่อยู่ใน Highlight "Display 6.0 in. …" แต่เห็นที่แถว Touch Panel หน้า 3 TC22) อย่าให้ `complete` เพียงเพราะ Highlight ครอบค่าหลัก `partial` ใช้เมื่อเงื่อนไขที่ไม่ถูกเน้นอยู่คนละหน้า อ่านไม่ชัด หรือต้องอนุมาน `partial_visible` ใช้ได้เฉพาะแถวที่มีหน้าอ้างและได้อ่านหน้านั้น แถวหัวข้อที่อ้างแค่โฟลเดอร์ไม่มีเลขหน้า (แถว 89 ข้อ ๕.๕) = `item_label_check`/`highlight_check` `not_applicable`

## Invariants

- input และ output เป็นคนละไฟล์ (ค่าเริ่มต้น `SOC_Check-YYYY-MM-DD-หัวข้อ.docx`) ห้ามเปลี่ยน TOR ข้อเสนอ Comply/Better เลขหน้า หรือ Highlight เดิม เว้นแต่ผู้ใช้สั่ง
- checks ที่ไม่ได้เปิดห้ามประเมินหรือรายงาน ห้ามตัดสิน TOR เว้นแต่เปิด `tor_decision`
- แยก `reference_check` จาก `heading_title_check`, `evidence_support`, `tor_decision`: หน้าอ้างถูกไม่ได้แปลว่าชื่อตรง หลักฐานครบ หรือผ่าน TOR; Highlight/เลขข้อผิดหรือขาดห้ามลด `reference_check` เป็น `mismatch` ถ้าเนื้อหาหน้ารองรับ claim
- หน้าที่อ้างมี metric/ค่า/หน่วยตรงกับข้อเสนอ ห้ามให้ `mismatch`/`unrelated`/`unverifiable` เพราะ token coverage ต่ำหรือภาษาต่างอย่างเดียว ห้ามหยิบตัวเลขมาเทียบจนกว่าจับคู่ `metric`, `unit`, `direction`, `threshold`, `verified_value` ได้ (เลขรุ่น เลขมาตรฐาน ความละเอียด หรือคนละ metric ใช้แทนกันไม่ได้)
- ผล block-level จาก script เปลี่ยนผลเดิมได้เฉพาะ `evidence_blocks.status: confident` ที่เลขข้อ metric ค่า หน่วยตรง และไม่มี candidate สูสี
- candidate reference เป็นคำแนะนำ ห้ามใช้ตัดสิน TOR จนกว่าผู้ใช้ยืนยัน ห้ามต่อข้อความต่างหน้าโดยไม่แจกแจงหน้า
- ช่องอ้างอิงว่างในแถวที่ต้องมีหลักฐาน = `reference_check: not_found` และ checks ที่ต้องอ่านหน้า = `unverifiable`; เอกสารที่ถูกอ้างแต่ไม่มีไฟล์ = ประเด็นแยกที่ต้องแจ้ง ไม่ใช่ `unverifiable` เงียบ ๆ

## results.json

```json
{"title": "ผลการตรวจสอบ SOC …", "audit_date": "9 ตุลาคม 2569", "mode": "full_audit",
 "options": ["evidence_support", "tor_decision"],
 "results": [{"row": 93, "item": "๕.๕.๑.๓", "reference": "<ช่องอ้างอิงดิบ>", "reference_file": "tc22.pdf",
   "reference_check": "match", "reference_detail": "…", "content_relevance": "related", "item_label_check": "match",
   "highlight_check": "partial_visible", "highlight_evidence": "…", "evidence_support": "fully_supported",
   "evidence_detail": "…", "tor_decision": "compliant", "tor_decision_basis": "…", "verified_value": "…",
   "tor_threshold": "…", "tor_claim_results": [], "declared_status": "not_selected",
   "declared_status_check": "not_applicable", "detail": "…", "key_issue": "…", "confidence": "high"}]}
```

- บังคับทุกแถว: `row` (เลขแถวในตาราง SOC), `item`, `reference_check`, `detail` เปิด `reference` → `reference_detail`; `item_label` → `item_label_check`; `highlight` → `highlight_check` + `highlight_evidence`; `evidence_support` → `evidence_support` + `evidence_detail`; `tor_decision` → `tor_decision`, `tor_decision_basis`, `verified_value`, `tor_threshold`, `tor_claim_results` (list), `declared_status`, `declared_status_check` **field บังคับห้ามเป็นค่าว่าง** ใช้ `-` หรือข้อความสั้น (แถวหัวข้อ/รุ่นที่ไม่มีเกณฑ์ใช้ `-`)
- `item` = เลขข้อเต็มจากเลขข้อใหญ่ลงมา (`๕.๘.๑.๑`) ไม่ใช่เลขดิบในตาราง (`๑.๑)`, `(ข้อย่อยไม่มีเลข)`) แถวไม่มีเลขใช้เลขของแถวก่อนหน้า เว็บปฏิเสธทั้งชุดถ้าผิดแถวเดียว
- `reference_file` = ไฟล์หลักฐานที่แถวนั้นใช้ ทุกแถวที่มีหน้าอ้าง (validator ใช้เลือก highlights)
- `key_issue`: เขียนเองทุกครั้งที่มีข้อค้นพบที่ผู้ใช้ต้องเห็น (ความผิดในเอกสารอ้างอิง เช่นป้ายเลขซ้ำ ข้อจำกัดของการตรวจอัตโนมัติ คำเตือนก่อนยื่น) ≤ ~280 ตัวอักษร ใจความสำคัญไว้ต้น ถ้าไม่ใส่ สคริปต์เลือกจาก field อื่นแล้วตัดที่ 300 ตัวอักษร ใส่เฉพาะสาเหตุที่หน้า/ชื่อ/Highlight/หลักฐานผิดหรือขาด เหตุผลของผล `better`/`non_compliant`/`mixed`/`unverifiable` หน้าแนะนำ และสิ่งที่ต้องแก้ ห้าม `row_type`, coverage, `tor_claim_results`, JSON ดิบ หรือข้อความหลักฐานเต็ม ทุกอย่างถูกต้อง = ประโยคสั้นหนึ่งประโยค
- ผล `compliant`/`better` ที่ควรตรวจซ้ำ ให้ `confidence: medium` สคริปต์เขียน "ผ่าน – ควรตรวจซ้ำ" และใส่สีเอง

```
python scripts/validate_audit_consistency.py results.json A.pdf=hl_a.json B.pdf=hl_b.json --output consistency.json
python scripts/append_results_to_docx.py <SOC.docx> results.json <SOC_Check.docx>
```

ชื่อก่อน `=` ตรงกับ `reference_file` (ชื่อซ้ำคนละโฟลเดอร์ใส่ path) exit 2 = มี `issues` ต้องทบทวนแถวนั้นก่อนส่ง (`skipped` = แถวที่ไม่มี highlights เช่นหนังสือแต่งตั้ง ไม่ใช่ข้อผิด)

### Compact Results (เฉพาะ `evidence_packet`)

เขียน `out/compact.json` (หัวไฟล์เหมือน results.json) แทน results.json ทุก token ที่เขียนแพงกว่าที่อ่าน 5 เท่า จึง**เขียนเฉพาะสิ่งที่ตัดสินเอง** แล้วรัน `python scripts/expand_results.py out/compact.json out/packet/job.json out/results.json` (prompt ให้ตรวจใหม่เฉพาะบางแถว: เพิ่ม `--rows 93,95`; exit 1 = แก้แถวที่บอกแล้วรันใหม่) ก่อน validator
- **เขียน `out/compact.json` ด้วย Write tool ครั้งเดียว** (JSON ตรง ๆ) ห้ามเขียนสคริปต์ Python สร้าง และ**ห้ามใช้ heredoc / `cat <<` / `echo` ใน shell** (ข้อความไทยมีเครื่องหมายคำพูด shell พังแล้วต้องเขียนใหม่ทั้งไฟล์) แก้แถวที่ expand แจ้งด้วย Edit
- **ไม่ต้องเขียน**: `item`, `reference`, `tor_claim_results`, `verified_value`/`tor_threshold` ที่เป็น `-`, `reference_file` เมื่อแถวมีไฟล์เดียว, `declared_status*` เมื่อ job.md บอกว่าไม่พบช่องติ๊ก, `heading_title_check` ของแถว `content`
- **ทุกแถวเขียน**: `row`, `reference_check`, `item_label_check`, `highlight_check`, `evidence_support`, `tor_decision`, `confidence`, `tor_decision_basis` (แถวที่ตัดสิน ทีละเงื่อนไข `เงื่อนไข: ค่าใน DS (หน้า X) → ผล` แม้ข้อเสนอคัดลอก TOR) + `verified_value`/`tor_threshold` เมื่อมีเกณฑ์; แถวหัวข้อ + `heading_title_check`; หลายไฟล์ + `reference_file`
- **แถวผ่าน** (reference `match`, label `match`/n/a, highlight `complete`/`partial_visible`/n/a, `fully_supported`, แถวหัวข้อที่อ้างแค่โฟลเดอร์ reference/evidence เป็น n/a ได้, `compliant`/`better`/n/a): **ไม่ต้องเขียน** `reference_detail`, `highlight_evidence`, `evidence_detail`, `detail`, `key_issue`, `content_relevance` สคริปต์ใส่ข้อความมาตรฐาน ยกเว้น `partial_visible` → เขียน `highlight_evidence` (rule 11); เลือกไฟล์จากหลายไฟล์ที่สคริปต์อธิบายไม่ได้ → เขียน `reference_detail` (ขั้นที่ 0)
- **แถวมีประเด็น**: เขียนทุก field แต่**ห้ามซ้ำข้อความข้าม field** แต่ละ field บอกเฉพาะแกนของตัวเอง
