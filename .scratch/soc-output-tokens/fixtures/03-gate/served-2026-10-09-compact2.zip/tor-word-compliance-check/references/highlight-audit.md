# Item label and Highlight audit

อ่านเฉพาะเมื่อเปิด `item_label` หรือ `highlight` และไม่มี evidence packet (ค่าของ `highlight_check` และ `partial_visible` อยู่ใน SKILL.md rule 11)

## Item label

ค้นหาเลขข้อของแถวในข้อความหน้า annotation content หรือบริเวณที่เน้น และยืนยันว่าเลขนั้นสัมพันธ์กับหลักฐานของแถว หากเอกสารผู้ผลิตไม่ควรมีเลข TOR ใช้ `not_applicable`; หากคาดหมายให้มีแต่ไม่พบใช้ `not_found`

## Highlight

1. ตรวจ Highlight/Underline annotation ก่อน
2. ตรวจสีพื้น กรอบ เส้นใต้ ลูกศร FreeText และเลขข้อที่ flatten ใน content stream; การไม่มี `/Annots` ไม่ได้แปลว่าไม่มี Highlight
3. Render และ crop เฉพาะหน้าที่ยังค้างรอบข้อความหลักฐาน
4. รวมผลทุกหน้าที่อ้างและตรวจว่าครอบคลุมทุก claim สำคัญ ไม่ใช่เพียงพบ annotation ใด ๆ

การผูกเลขข้อกับ Highlight ต้องเรียงหลักฐานตามลำดับ: บรรทัดเดียวกันและคอลัมน์เดียวกัน (Y ทับกันและใกล้กันแนวนอน) → แถวที่ชิดเหนือ/ใต้เพียงแถวเดียว → metric/ตัวเลข/หน่วยตรงกัน Highlight ที่ Y เดียวกันแต่อยู่อีกคอลัมน์ไม่ใช่แถวเดียวกัน ห้ามเลือก Highlight แถวข้างเคียงเพียงเพราะระยะกรอบใกล้กว่า หากหลาย candidate สูสีกันให้ render ตรวจภาพหรือใช้ `unverifiable`

ผลจาก `extract_pdf_highlights.py` มี `evidence_blocks` แยกรายเลขข้อ ห้ามนำข้อความทั้งหน้ามากำหนด metric เดียว เพราะหนึ่งหน้าอาจมีหลายแถวและหลาย metric:

- `confident` + `same_row`: เลขข้อกับหลักฐานอยู่บรรทัดเดียวกัน (Y ทับกันเกือบครึ่งความสูงและห่างกันแนวนอนไม่เกิน ~36 pt) Highlight ที่ Y เดียวกันแต่อยู่อีกคอลัมน์ไม่นับ หลักฐานรวมชื่อ metric กับค่าที่อยู่แถวเดียวกัน
- `confident` + `adjacent_row`: เลขข้ออยู่ชิดเหนือ/ใต้แถวเดียว (≤ 10 pt) และไม่มีแถวอื่นใกล้พอ ๆ กัน
- `fallback` (`nearest_fallback`): ใกล้หลายแถวพอ ๆ กัน หรือห่างเกินกว่าจะมั่นใจ `evidence` คือ **ทุก** candidate ใช้ได้เพียงค้น candidate ต้อง render ตรวจภาพก่อนสรุป
- `unverifiable`: ไม่มี Highlight ใกล้พอ
- `off_page` (`outside_page_box`): ป้ายอยู่นอกกรอบหน้า (เช่น y เกินความสูงหน้า) ผู้อ่านมองไม่เห็น ห้ามนับเป็นเลขข้อที่พบ ไม่ถูกใส่ใน `evidence_by_item` ป้าย/Highlight ทุกตัวมี `off_page: true/false`

FreeText แบบ callout (มีเส้นชี้) ผูกกับจุดที่ปลายเส้นชี้ (`callout_tip`) ไม่ใช่กรอบข้อความ

`unlabeled_highlights` ต่อหน้า คือ Highlight จริงที่ไม่มีเลขข้อใดผูก (เช่น รายการ "Markets and Applications" หรือย่อหน้า Warranty) ไม่ใช่หลักฐานของแถวใดโดยอัตโนมัติ ใช้เมื่อแถวที่อ้างหน้านั้นไม่มีป้ายของตัวเอง (เช่น RFD40 หน้า 3 "Host Connection" ของข้อ 2.1 ไม่มีป้าย) และต้องอ่านเนื้อหาตัดสินเอง

script ไม่นับ appearance ของ annotation ซ้ำเป็น `EmbeddedHighlight`; `EmbeddedHighlight`/`EmbeddedLabel` มาจาก content stream ของหน้าเท่านั้น

เมื่อมี PyMuPDF ให้รัน `python scripts/extract_pdf_highlights.py input.pdf output.json` เพื่อดึงข้อความใต้ annotation และสีเหลืองที่ฝังในหน้า พร้อมจับคู่ FreeText/เลขข้อสีแดงตามตำแหน่ง หาก script ใช้ไม่ได้ ให้ render ตรวจภาพและใช้ `unverifiable` แทนการสรุปว่า `not_found`

ผล `highlight_check`: `complete`, `partial_visible`, `partial`, `not_found`, `unverifiable`, `not_applicable` และบันทึก `highlight_evidence` ระบุสิ่งที่ครอบคลุมหรือขาด หากเนื้อหาไม่เกี่ยวข้องให้ใช้ `not_applicable` พร้อมเหตุผล

**`partial_visible`** (นับเป็นผ่าน สีเขียว): Highlight ไม่ครอบทุกเงื่อนไขของ TOR แต่หลักฐานของเงื่อนไขที่ไม่ถูกเน้นอยู่ในแถวอื่นของ**หน้าเดียวกับที่ SOC อ้าง**และอ่านเห็นชัดเจน ไม่ต้องมี Highlight แยก ตัวอย่าง (๑.๓): TOR ขอ "หน้าจอสัมผัส" Highlight ครอบเฉพาะขนาดจอ แต่แถว "Touch Panel" อยู่ในตารางหน้าเดียวกัน ให้ `partial_visible` และเขียนใน `highlight_evidence` ว่าคำใดไม่ได้ Highlight และพบที่แถวใด (เช่น "สัมผัส: ไม่ได้ highlight แต่เห็นที่แถว Touch Panel หน้าเดียวกัน") ห้ามใส่เรื่องนี้ใน `key_issue` และห้ามลด `confidence`
ใช้ `partial` เมื่อเงื่อนไขที่ไม่ถูกเน้นอยู่**คนละหน้า** อ่านไม่ชัด หรือต้องอนุมานจึงจะเห็นว่ารองรับ

**แถวหัวข้อย่อยที่ข้อเสนอคัดลอก TOR**: ไม่ตรวจเลขข้อกำกับและ Highlight ให้ `item_label_check: not_applicable` และ `highlight_check: not_applicable` (SKILL.md rule 10)
