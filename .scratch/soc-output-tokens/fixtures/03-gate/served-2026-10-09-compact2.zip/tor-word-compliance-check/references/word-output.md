# Word output: เมื่อ script ล้ม และ render QA

schema ของ results.json, field บังคับ และคำสั่งอยู่ใน SKILL.md หัวข้อ "results.json"

## append_results_to_docx.py

`python scripts/append_results_to_docx.py input.docx results.json output.docx` เพิ่ม section แนวนอนต่อท้ายโดยไม่แก้ตาราง SOC เดิม สรุป `reference_check`, `highlight_check`, `evidence_support`, `tor_decision`, `declared_status_check` แยกกัน และใส่สี/สถานะย่อยตาม deliverables.md เอง script ตรวจ `mode`, ความสัมพันธ์ของ options และ field บังคับก่อนสร้าง ผลที่ขาด field หรือ `tor_decision` ที่ไม่มี `evidence_support` ทำให้หยุดพร้อมข้อความ (`<context> requires <fields> at result <n>`: n นับจาก 1 ตามลำดับใน `results`)

- **`KeyError: "no style with name 'Table Grid'"`**: SOC ไม่มีสไตล์ Table Grid ทำสำเนาชั่วคราวของ docx ที่เพิ่มสไตล์ (`doc.styles.add_style('Table Grid', WD_STYLE_TYPE.TABLE)` แล้วใส่เส้นขอบ) ใช้เป็น input แล้วตรวจว่าตาราง SOC เดิมข้อความเท่าเดิม ห้ามแก้ไฟล์ต้นฉบับ
- **ค่าว่างใน field บังคับ** (`TOR decision requires verified_value, tor_threshold`): ใส่ `-` หรือข้อความสั้น เช่น "ตามข้อความ SOC"
- `key_issue` ที่ไม่ได้ใส่ script เลือกจาก `highlight_evidence` (เมื่อ `partial`) หรือ `evidence_detail` (เมื่อไม่ `fully_supported`) แล้วตัดที่ 300 ตัวอักษร (`compose_key_issue()`) ใจความท้ายข้อความอาจหาย จึงต้องเขียน `key_issue` เองเมื่อมีข้อค้นพบสำคัญ

## validate_audit_consistency.py

รันครั้งเดียวกับ highlights ทุกไฟล์ (`FILE=highlights.json` โดย FILE ตรงกับ `reference_file` ทั้ง path หรือท้าย path; ไฟล์ชื่อซ้ำคนละโฟลเดอร์ใส่ path เช่น `2.5/1./Datasheet.pdf=hl1.json`; `reference_file` ที่ตรงหลายไฟล์ถูก skip; ไฟล์เดียวใส่ path อย่างเดียวได้) อ่านเลขหน้าจาก "page N" และ "หน้า N" (เลขไทยได้) exit 2 เมื่อมี `issues`

## QA ก่อนส่งมอบ

render DOCX ทุกหน้า ตรวจ clipping ตารางล้น header/footer ซ้อน และหัวตารางซ้ำ ถ้าไม่มี renderer ทำ structural QA: เปิดไฟล์กลับได้ ZIP/OOXML ไม่เสีย ตารางต้นฉบับเท่าเดิม จำนวนผลตรง JSON section ผลเป็นแนวนอน field บังคับครบ แล้วบอกว่า visual QA ยังไม่ได้ทำ

renderer ที่ไม่มีฟอนต์ไทย (TH Sarabun New) อาจแสดงข้อความไทยผสมอังกฤษเพี้ยน (ช่องว่างแทรกกลางคำ) ในภาพเท่านั้น ให้ยืนยันด้วยการดึงข้อความจาก docx โดยตรง และบอกผู้ใช้ว่าเป็นข้อจำกัดของ visual QA ไม่ใช่ไฟล์เสีย
