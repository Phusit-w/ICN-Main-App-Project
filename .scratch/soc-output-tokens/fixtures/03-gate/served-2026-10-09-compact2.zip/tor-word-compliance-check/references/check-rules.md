# Check rules: merged cells, ชื่อหัวข้อคำต่อคำ และช่อง Comply/Better

ค่าของ check อื่น ๆ อยู่ใน SKILL.md หัวข้อ "ค่าของแต่ละ check"

## จำแนกแถวจาก merged cells

แถวที่เซลล์เนื้อหาหลายคอลัมน์อ้างถึง `<w:tc>` เดียวกัน หรือมี `w:gridSpan` ครอบคลุมคอลัมน์หลัก มักเป็น `section_heading_row` ห้ามตัดสินจากเลขข้อหรือช่องอ้างอิงอย่างเดียว ใช้ `scripts/inspect_word_table.py` ดู `grid_span`, `vmerge`, drawing และ checkbox

## Heading title แบบคำต่อคำ (เมื่อผู้ใช้ขอให้ "ชื่อตรงกับ Datasheet")

ใช้ชื่อหัวข้อบน Datasheet/Catalog เป็นชื่อมาตรฐานของ `system_heading_row`

- `match`: ตรงคำต่อคำหลังปรับเฉพาะช่องว่าง ตัวพิมพ์ใหญ่/เล็ก และวรรคตอนที่ไม่เปลี่ยนความหมาย
- `mismatch`: พบหัวข้อบนหน้าที่อ้าง แต่ SOC เพิ่ม ตัด หรือเปลี่ยนคำ (SOC `CATM IV Aircraft Stand Guidance Equipment Management System` เทียบ DS `IV Aircraft Stand Guidance Equipment Management System` = `mismatch` เพราะมี `CATM` เพิ่ม)
- `unverifiable`: ไม่มีเลขหน้า เปิดหน้าไม่ได้ หรือยังไม่พบหัวข้อบน DS
- `not_applicable`: ไม่ใช่ `system_heading_row`

ไม่นำเลขข้อ SOC (`3.2`) ไปเทียบกับเลขหัวข้อใน DS แต่เก็บเลข/Roman numeral ที่เป็นส่วนของชื่อ DS ในชื่อที่แนะนำ บันทึก `soc_heading_title`, `datasheet_heading_title`, `suggested_heading_title`, `heading_title_detail` ไม่มีเลขหน้าใช้ข้อความ `ไม่พบเลขหน้าอ้างอิง จึงยังไม่ได้ตรวจสอบว่าชื่อหัวข้อตรงกับ Datasheet หรือไม่` ห้ามแก้ชื่อใน SOC เว้นแต่ผู้ใช้ขอ

## ช่อง Comply/Better

ช่องว่างจาก text extraction ยังไม่ใช่ `not_selected` จนกว่าจะตรวจ `w14:checkbox`, legacy form field, `w:sym`, Unicode checkbox, drawing/image และ content control ในเซลล์ พบสัญญาณที่อ่านสถานะไม่ได้ = `declared_status: unverifiable` ใช้ `not_selected` เมื่อไม่พบทั้งข้อความและ control/drawing ที่เลือกไว้
