# Metric matching across languages

ใช้เมื่อ TOR/ข้อเสนอและหลักฐานคนละภาษา หรือมีตัวเลขหลายชนิดในหน้าเดียวกัน

1. แยก claim เป็น `metric`, `value`, `unit`, `direction`, เงื่อนไข และ `source_text`
2. Normalize metric ด้วยคำพ้องเฉพาะโดเมน เช่น `ความละเอียดของภาพ`, `Resolution`, `Acquisition Resolution` → `image_resolution`
3. Normalize หน่วยก่อนเปรียบเทียบ เช่น `ล้านพิกเซล`, `million pixels`, `MP` → pixel scale เดียวกัน
4. จับคู่ metric ก่อนตัวเลขเสมอ ตัวเลขที่เท่ากันแต่ metric ต่างกันใช้ไม่ได้
5. ใช้ lexical/token coverage เพื่อค้น candidate หรือจัดลำดับการตรวจเท่านั้น ห้ามใช้เป็นเหตุผลเดียวของ `mismatch`, `unrelated` หรือ `unverifiable`
6. รัน `scripts/compare_tor_values.py` เมื่อมีเกณฑ์เชิงตัวเลข และตรวจผลย้อนกลับกับข้อความต้นฉบับ

เลือก metric ภายใน `evidence_block` ของเลขข้อนั้นเท่านั้น ห้ามใช้ฟังก์ชันที่คืน metric แรกจากข้อความทั้งหน้า หาก block ไม่มี metric ชัด ให้ fallback ไปค้น candidate หรือ render แต่ห้าม override ผลเดิมอัตโนมัติ

Metric ที่มีหลาย subclaims เช่น Minimum Illumination ให้แยก `minimum_illumination_color` และ `minimum_illumination_bw` แล้วเปรียบเทียบแต่ละค่าตาม direction ก่อนรวมผล ข้อมูลประกอบที่ TOR ไม่ได้บังคับ เช่นเงื่อนไขเลนส์หรือ AGC ให้มีผลต่อความครบของ evidence/Highlight แต่ไม่ทำให้ผล TOR ของค่า lux เป็น `unverifiable`

สำหรับ `image_resolution` ให้ normalize `3840 x 2160`, `3840×2160`, `3840*2160` และ `3840 (H) × 2160 (V)` เป็น ordered pair `(3840, 2160)` ใช้ได้เฉพาะเมื่อฝั่ง TOR/ข้อเสนอระบุบริบท resolution/pixel และหลักฐานอยู่ใน confident block ห้ามจับเลขเดี่ยวจากคนละตำแหน่งมาประกอบเป็นคู่ และค่าเริ่มต้นห้ามสลับแกน การเปรียบเทียบ `minimum` ต้องให้ทั้ง width และ height ถึงเกณฑ์; สูงกว่าบางแกนแต่ต่ำกว่าอีกแกนใช้ `non_compliant`

Consistency gate ก่อนส่งผล:

- หน้าที่อ้างมี metric/ค่า/หน่วยตรงกับข้อเสนอ → `reference_check` ต้องไม่เป็น `mismatch` เพราะภาษาแตกต่าง
- ค่าหลักฐานผ่านเกณฑ์และ metric/หน่วยตรง → `tor_decision` ต้องเป็น `compliant` หรือ `better` ตามทิศทาง เว้นแต่มี claim บังคับอื่นค้าง
- Highlight ขาดหรือจับผิดแถวเปลี่ยนเฉพาะ `highlight_check`/`item_label_check`; ไม่เปลี่ยนผลอ้างอิงหรือผลเชิงตัวเลขโดยอัตโนมัติ

ตัวอย่าง: TOR `70 ล้านพิกเซลหรือดีกว่า`, ข้อเสนอ `116 million pixel`, Datasheet `Acquisition Resolution: 116 million pixels` ให้ metric=`image_resolution`, unit=`million pixels`, direction=`minimum`; ผลหลักฐาน `fully_supported` และผล TOR `better`
