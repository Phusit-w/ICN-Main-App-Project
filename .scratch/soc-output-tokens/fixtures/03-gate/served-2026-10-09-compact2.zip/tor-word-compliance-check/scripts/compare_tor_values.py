from __future__ import annotations

import argparse
import json
from pathlib import Path
import re


UNIT_FACTORS = {
    "b": ("bytes", 1), "kb": ("bytes", 10**3), "mb": ("bytes", 10**6),
    "gb": ("bytes", 10**9), "tb": ("bytes", 10**12),
    "hz": ("frequency", 1), "khz": ("frequency", 10**3),
    "mhz": ("frequency", 10**6), "ghz": ("frequency", 10**9),
    "ms": ("time", 0.001), "s": ("time", 1), "sec": ("time", 1),
    "mm": ("length", 0.001), "cm": ("length", 0.01), "m": ("length", 1),
    "fps": ("fps", 1), "db": ("db", 1), "dbm": ("dbm", 1),
    "pixel": ("pixel", 1), "pixels": ("pixel", 1),
    "mp": ("pixel", 10**6), "megapixel": ("pixel", 10**6),
    "million pixel": ("pixel", 10**6), "million pixels": ("pixel", 10**6),
    "ล้านพิกเซล": ("pixel", 10**6), "core": ("core", 1),
    "port": ("port", 1), "unit": ("unit", 1), "%": ("percent", 1),
}


def normalize_unit(value: str) -> str:
    return " ".join(value.strip().lower().replace("seconds", "s").replace("second", "s").split())


METRIC_ALIASES = {
    "resolution": "image_resolution",
    "image resolution": "image_resolution",
    "acquisition resolution": "image_resolution",
    "max resolution": "image_resolution",
    "maximum resolution": "image_resolution",
    "pixel resolution": "image_resolution",
    "ความละเอียดของภาพ": "image_resolution",
    "ความละเอียดภาพ": "image_resolution",
}


def normalize_metric(value: str) -> str:
    key = re.sub(r"[^\wก-๙]+", " ", value.strip().lower()).strip()
    return METRIC_ALIASES.get(key, key.replace(" ", "_"))


def parse_dimension(value: object) -> tuple[int, int] | None:
    text = str(value).lower()
    match = re.search(r"(\d{2,6})\s*(?:\(\s*h\s*\))?\s*[x×*]\s*(\d{2,6})\s*(?:\(\s*v\s*\))?", text, re.I)
    return (int(match.group(1)), int(match.group(2))) if match else None


def convert(value: float, unit: str) -> tuple[str, float]:
    key = normalize_unit(unit)
    if key not in UNIT_FACTORS:
        raise ValueError(f"unsupported unit: {unit}")
    dimension, factor = UNIT_FACTORS[key]
    return dimension, float(value) * factor


def compare_claim(claim: dict) -> dict:
    required = ["claim", "metric", "direction", "threshold", "threshold_unit",
                "verified_metric", "verified_value", "verified_unit", "source_text"]
    missing = [field for field in required if field not in claim or claim[field] in (None, "")]
    if missing:
        return {**claim, "result": "unverifiable", "detail": f"missing structured fields: {', '.join(missing)}"}
    metric = normalize_metric(claim["metric"])
    verified_metric = normalize_metric(claim["verified_metric"])
    if metric != verified_metric:
        return {**claim, "result": "unverifiable", "detail": "metric mismatch; identifier or another property may have been selected"}
    threshold_pair = parse_dimension(claim["threshold"])
    verified_pair = parse_dimension(claim["verified_value"])
    if threshold_pair or verified_pair:
        if metric != "image_resolution" or not threshold_pair or not verified_pair:
            return {**claim, "result": "unverifiable", "detail": "dimension pairs require image_resolution on both sides"}
        direction = claim["direction"]
        if direction == "minimum":
            passed = all(v >= t for v, t in zip(verified_pair, threshold_pair))
            better = passed and any(v > t for v, t in zip(verified_pair, threshold_pair))
        elif direction == "maximum":
            passed = all(v <= t for v, t in zip(verified_pair, threshold_pair))
            better = passed and any(v < t for v, t in zip(verified_pair, threshold_pair))
        elif direction == "exact":
            passed, better = verified_pair == threshold_pair, False
        else:
            return {**claim, "result": "unverifiable", "detail": "direction must be minimum, maximum, or exact"}
        result = "better" if better else ("compliant" if passed else "non_compliant")
        return {**claim, "result": result,
                "detail": f"compared {metric}: {verified_pair[0]}x{verified_pair[1]} against "
                          f"{direction} {threshold_pair[0]}x{threshold_pair[1]}"}
    try:
        threshold_dimension, threshold = convert(claim["threshold"], claim["threshold_unit"])
        verified_dimension, verified = convert(claim["verified_value"], claim["verified_unit"])
    except (TypeError, ValueError) as exc:
        return {**claim, "result": "unverifiable", "detail": str(exc)}
    if threshold_dimension != verified_dimension:
        return {**claim, "result": "unverifiable", "detail": "unit dimensions do not match"}

    direction = claim["direction"]
    if direction == "minimum":
        passed, better = verified >= threshold, verified > threshold
    elif direction == "maximum":
        passed, better = verified <= threshold, verified < threshold
    elif direction == "exact":
        passed, better = verified == threshold, False
    else:
        return {**claim, "result": "unverifiable", "detail": "direction must be minimum, maximum, or exact"}
    result = "better" if passed and better else ("compliant" if passed else "non_compliant")
    return {**claim, "result": result,
            "detail": f"compared {metric}: {claim['verified_value']} {claim['verified_unit']} "
                      f"against {direction} {claim['threshold']} {claim['threshold_unit']}"}


def main() -> None:
    parser = argparse.ArgumentParser(description="Compare pre-structured TOR values without mining arbitrary numbers")
    parser.add_argument("input_json", type=Path)
    parser.add_argument("output_json", type=Path)
    args = parser.parse_args()
    data = json.loads(args.input_json.read_text(encoding="utf-8"))
    claims = data.get("claims")
    if not isinstance(claims, list) or not claims:
        raise ValueError("input JSON must contain a non-empty claims list")
    output = {"claims": [compare_claim(claim) for claim in claims]}
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(args.output_json)


if __name__ == "__main__":
    main()
