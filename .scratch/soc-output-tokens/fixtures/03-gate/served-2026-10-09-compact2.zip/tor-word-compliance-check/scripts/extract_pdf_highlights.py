from __future__ import annotations

import argparse
import json
import math
import re
from pathlib import Path

try:
    import pymupdf
except ImportError as exc:
    raise SystemExit("PyMuPDF is required: run with a Python environment that provides 'pymupdf'") from exc


THAI_DIGITS = str.maketrans("๐๑๒๓๔๕๖๗๘๙", "0123456789")

# Distances in PDF points. Calibrated on the MOF_RFID ๕.๕ datasheets (ticket 02).
SAME_ROW_MAX_GAP = 36       # label to mark, horizontally, on one visual row
SAME_ROW_MIN_OVERLAP = 0.4  # shared height, as a share of the shorter box
ROW_TOP_ALIGN = 4           # a metric name and its value start at the same y
CONTINUATION_GAP = 2        # a highlight that wraps onto the next line
CONTINUATION_X_OVERLAP = 8  # ... and still shares this much width with the line above
ADJACENT_MAX = 10           # a label right above/below its only nearby row
NEAREST_TOLERANCE = 12      # other marks this close to the nearest are candidates too
FALLBACK_MAX = 90           # beyond this no mark is near enough to be a candidate


def item_numbers(value: str) -> list[str]:
    return re.findall(r"\d+(?:\.\d+)+", (value or "").translate(THAI_DIGITS))


def rect_distance(a: pymupdf.Rect, b: pymupdf.Rect) -> float:
    dx = max(a.x0 - b.x1, b.x0 - a.x1, 0)
    dy = max(a.y0 - b.y1, b.y0 - a.y1, 0)
    return math.hypot(dx, dy)


def horizontal_gap(a: pymupdf.Rect, b: pymupdf.Rect) -> float:
    return max(a.x0 - b.x1, b.x0 - a.x1, 0)


def same_row(anchor: pymupdf.Rect, mark: pymupdf.Rect) -> bool:
    """Share most of a line's height AND sit close in x: a mark at the same y in another column is not this row."""
    y_overlap = min(anchor.y1, mark.y1) - max(anchor.y0, mark.y0)
    shorter = min(anchor.height, mark.height)
    return (y_overlap > 0 and y_overlap >= SAME_ROW_MIN_OVERLAP * shorter
            and horizontal_gap(anchor, mark) <= SAME_ROW_MAX_GAP)


def row_mates(a: pymupdf.Rect, b: pymupdf.Rect) -> bool:
    """A metric name beside its value, or one highlight wrapping onto the next line."""
    if abs(a.y0 - b.y0) <= ROW_TOP_ALIGN and horizontal_gap(a, b) <= SAME_ROW_MAX_GAP:
        return True
    vertical_gap = max(a.y0 - b.y1, b.y0 - a.y1, 0)
    x_overlap = min(a.x1, b.x1) - max(a.x0, b.x0)
    return vertical_gap <= CONTINUATION_GAP and x_overlap > CONTINUATION_X_OVERLAP


def row_of(seeds: list[int], rects: list[pymupdf.Rect]) -> list[int]:
    chosen = set(seeds)
    grew = True
    while grew:
        grew = False
        for index, rect in enumerate(rects):
            if index not in chosen and any(row_mates(rect, rects[other]) for other in chosen):
                chosen.add(index)
                grew = True
    return sorted(chosen)


def bind(anchor: pymupdf.Rect, rects: list[pymupdf.Rect]) -> tuple[str, str, list[int]]:
    """(status, selection_rule, mark indexes) for one label. Never drifts to another row or column."""
    same = [index for index, rect in enumerate(rects) if same_row(anchor, rect)]
    if same:
        return "confident", "same_row", row_of(same, rects)
    distances = sorted((rect_distance(anchor, rect), index) for index, rect in enumerate(rects))
    if not distances or distances[0][0] > FALLBACK_MAX:
        return "unverifiable", "none", []
    minimum, best = distances[0]
    nearest = [index for distance, index in distances if distance <= minimum + NEAREST_TOLERANCE]
    row = row_of([best], rects)
    if minimum <= ADJACENT_MAX and set(nearest) <= set(row):
        return "confident", "adjacent_row", row
    # Several rows are about as near: report every candidate, never pick one.
    return "fallback", "nearest_fallback", row_of(nearest, rects)


def off_page(rect: pymupdf.Rect, page_rect: pymupdf.Rect) -> bool:
    """Less than half of it is inside the page box, so nobody reading the page sees it."""
    visible = pymupdf.Rect(rect) & page_rect
    return visible.is_empty or visible.get_area() < 0.5 * rect.get_area()


def callout_tip(annotation) -> pymupdf.Rect | None:
    """A FreeText callout points at its evidence with the first point of its line.
    Only /IT /FreeTextCallout counts: PyMuPDF writes a dummy /CL on plain FreeText too."""
    document = annotation.parent.parent
    if document.xref_get_key(annotation.xref, "IT") != ("name", "/FreeTextCallout"):
        return None
    points = annotation.vertices
    if not points:
        return None
    tip = pymupdf.Point(points[0])
    return pymupdf.Rect(tip, tip)


def evidence_entry(mark: dict) -> dict:
    return {"kind": mark["kind"], "text": mark["text"], "rect": mark["rect"]}


def content_only(document: pymupdf.Document) -> pymupdf.Document:
    """A copy without annotations: get_drawings() and get_text() include annotation appearances,
    which would report every Highlight and every yellow FreeText box again as embedded."""
    copy = pymupdf.open("pdf", document.tobytes())
    for page in copy:
        while page.first_annot:
            page.delete_annot(page.first_annot)
    return copy


def is_red(color: int) -> bool:
    red, green, blue = (color >> 16) & 255, (color >> 8) & 255, color & 255
    return red >= 180 and green <= 100 and blue <= 100


def is_yellow(color) -> bool:
    return bool(color) and color[0] >= 0.85 and color[1] >= 0.80 and color[2] <= 0.35


def merge_rects(rects: list[pymupdf.Rect]) -> list[pymupdf.Rect]:
    groups: list[pymupdf.Rect] = []
    for rect in sorted(rects, key=lambda value: (value.y0, value.x0)):
        for index, group in enumerate(groups):
            horizontal_gap = max(rect.x0 - group.x1, group.x0 - rect.x1, 0)
            vertical_gap = max(rect.y0 - group.y1, group.y0 - rect.y1, 0)
            x_overlap = min(rect.x1, group.x1) - max(rect.x0, group.x0)
            y_overlap = min(rect.y1, group.y1) - max(rect.y0, group.y0)
            if ((vertical_gap <= 1.5 and horizontal_gap <= 4)
                    or (vertical_gap <= 8 and x_overlap > 8)
                    or (horizontal_gap <= 8 and y_overlap > 2)):
                groups[index] = group | rect
                break
        else:
            groups.append(pymupdf.Rect(rect))
    return groups


def extract(pdf_path: Path) -> list[dict]:
    document = pymupdf.open(pdf_path)
    clean_document = content_only(document)
    output = []
    for page_number, (page, clean) in enumerate(zip(document, clean_document), start=1):
        marks = []
        labels = []
        anchors: list[pymupdf.Rect] = []
        for annotation in page.annots() or []:
            kind = annotation.type[1]
            if kind in {"Highlight", "Underline", "Square"}:
                text = " ".join(clean.get_textbox(annotation.rect).split())
                marks.append({"kind": kind, "text": text, "rect": list(annotation.rect)})
            elif kind == "FreeText":
                content_text = annotation.info.get("content", "")
                items = item_numbers(content_text)
                if items:
                    label = {"kind": "FreeText", "content": content_text, "items": items,
                             "rect": list(annotation.rect)}
                    tip = callout_tip(annotation)
                    if tip is not None:
                        label["callout_tip"] = [tip.x0, tip.y0]
                    labels.append(label)
                    anchors.append(tip if tip is not None else pymupdf.Rect(annotation.rect))

        for block in clean.get_text("dict").get("blocks", []):
            for line in block.get("lines", []):
                for span in line.get("spans", []):
                    items = item_numbers(span.get("text", ""))
                    if items and is_red(span.get("color", 0)):
                        labels.append({"kind": "EmbeddedLabel", "content": span["text"], "items": items,
                                       "rect": list(span["bbox"])})
                        anchors.append(pymupdf.Rect(span["bbox"]))

        yellow = [pymupdf.Rect(drawing["rect"]) for drawing in clean.get_drawings()
                  if is_yellow(drawing.get("fill"))]
        for rect in merge_rects(yellow):
            expanded = pymupdf.Rect(rect.x0 - 1, rect.y0 - 1, rect.x1 + 1, rect.y1 + 1)
            text = " ".join(clean.get_textbox(expanded).split())
            if text:
                marks.append({"kind": "EmbeddedHighlight", "text": text, "rect": list(rect)})

        for entry in labels + marks:
            entry["off_page"] = off_page(pymupdf.Rect(entry["rect"]), page.rect)
        visible = [index for index, mark in enumerate(marks) if not mark["off_page"]]
        visible_rects = [pymupdf.Rect(marks[index]["rect"]) for index in visible]

        evidence: dict[str, list[dict]] = {}
        evidence_blocks: dict[str, list[dict]] = {}
        bound: set[int] = set()
        for label, anchor in zip(labels, anchors):
            if label["off_page"]:
                status, rule, chosen = "off_page", "outside_page_box", []
            else:
                status, rule, picked = bind(anchor, visible_rects)
                chosen = [marks[visible[index]] for index in picked]
                bound.update(visible[index] for index in picked)
            for item in label["items"]:
                if not label["off_page"]:
                    evidence.setdefault(item, []).extend({"kind": mark["kind"], "text": mark["text"]}
                                                         for mark in chosen)
                evidence_blocks.setdefault(item, []).append({
                    "status": status,
                    "label": label["content"],
                    "label_rect": label["rect"],
                    "evidence": [evidence_entry(mark) for mark in chosen],
                    "selection_rule": rule,
                })
        # Real highlights that no label claims (e.g. a "Markets and Applications" list): keep them
        # visible to the reviewer, but never as any row's evidence.
        unlabeled = [evidence_entry(marks[index]) for index in visible if index not in bound]
        output.append({"page": page_number, "labels": labels, "highlights": marks,
                       "evidence_by_item": evidence, "evidence_blocks": evidence_blocks,
                       "unlabeled_highlights": unlabeled})
    return output


def main() -> None:
    parser = argparse.ArgumentParser(description="Extract annotation and flattened PDF highlight evidence")
    parser.add_argument("input_pdf", type=Path)
    parser.add_argument("output_json", type=Path)
    args = parser.parse_args()
    data = extract(args.input_pdf)
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"pages": len(data), "labels": sum(len(p["labels"]) for p in data),
                      "highlights": sum(len(p["highlights"]) for p in data)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
