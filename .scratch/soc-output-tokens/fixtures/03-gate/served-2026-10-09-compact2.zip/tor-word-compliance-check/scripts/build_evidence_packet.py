"""Evidence packet builder v2: the facts of every SOC row of one major item, plus image crops.

Prepares facts only. It never judges a row: every verdict stays with Claude (ADR 0008).
Per row: the row kind from the numbering, the TOR, offered and reference text, every file in the cited
folder as a candidate, and for each cited page the item labels numbered like the row plus a pointer to
the page file. A page file (text, every highlight once, every label with the highlights bound to it) is
written once per job in pages/, however many rows cite it (extract_pdf_highlights does the label binding).
Image or low-text pages also get PNG crops around their marks. Per job: the documents that are not
datasheets, SOC or TOR, with their first-page text; per cited PDF, the pages carrying a label of the
major item's rows (whole file) and the extractor output the validator needs.

v2 (2026-10-08): live Runner runs on v1 cost more quota than the old flow, because Claude read every
row packet and page as indented JSON. Claude now reads job.md (all rows in one file) and pages/*.md;
job.json keeps the same facts for scripts (check_page_reads.py, the SOC Runner).
"""
from __future__ import annotations

import argparse
import functools
import hashlib
import json
import os
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path

try:
    import pymupdf
except ImportError as exc:
    raise SystemExit("PyMuPDF is required: run with a Python environment that provides 'pymupdf'") from exc
from docx import Document

from extract_pdf_highlights import THAI_DIGITS, content_only, extract
from inspect_word_table import cell_signals

LOW_TEXT_CHARS = 150      # fewer non-space characters than this: an image page, so it gets crops
CROP_PAD = 36             # points around a mark
CROP_ZOOM = 2             # 144 dpi, small print stays readable
WHOLE_PAGE_ZOOM = 1.5     # a low-text page with no marks at all
PAGE_NUMBER_BAND = 0.08   # share of the page height, top and bottom, where a printed page number sits
FIRST_PAGE_TEXT_MAX = 2000
IMAGE_MAX_EDGE = 1568     # Claude downsizes a longer image edge to this many pixels
IMAGE_PIXELS_PER_TOKEN = 750
DOCUMENT_EXTENSIONS = {".pdf", ".doc", ".docx", ".xls", ".xlsx", ".jpg", ".jpeg", ".png", ".tif", ".tiff"}

ABSOLUTE_LABEL = re.compile(r"^[0-9๐-๙]+(?:\.[0-9๐-๙]+)*\.?$")   # "๕.๕", "5.5.1." (not "๑)")
ROW_NUMBER = re.compile(r"^\(?(\d+(?:\.\d+)*)[.)]?$")             # "๑.๑)", "(2)", "5.5"
# Stops before the next folder number: "หน้า 1 2.2 …" cites page 1 only.
PAGE_PART = re.compile(r"หน้า(?:ที่)?\s*(\d+(?:\s*(?:,|-|–|และ)\s*\d+)*)")
TOR_PART = re.compile(r"(?<![A-Za-z])TOR(?![A-Za-z])|ขอบเขตของงาน", re.IGNORECASE)
CHAPTER = re.compile(r"(?:ส่วนที่|บทที่)\s*(\d+)")


def arabic(value: str) -> str:
    return (value or "").translate(THAI_DIGITS)


def row_segments(number: str) -> list[str] | None:
    """A row's item number as segments ("๑.๑)" → ["1", "1"]), or None when the cell isn't a number."""
    match = ROW_NUMBER.match(re.sub(r"\s+", "", arabic(number)))
    return [str(int(part)) for part in match.group(1).split(".")] if match else None


def absolute_key(number: str) -> list[str] | None:
    """The segments of an absolute item number like "๕.๕" (never "๑)"), as the web importer reads it."""
    compact = re.sub(r"\s+", "", number or "")
    return row_segments(compact) if ABSOLUTE_LABEL.match(compact) else None


def major_item_rows(rows: list[list[str]], major_item: str) -> list[int]:
    """Indexes of the rows of one major item: from its own row up to the next item number outside it.
    A bare "1" inside ๕.๕ is a child row; it ends a whole major item ("๕") only."""
    key = absolute_key(major_item)
    if key is None:
        raise ValueError(f"not an item number: {major_item}")
    chosen: list[int] = []
    for index, cells in enumerate(rows):
        segments = absolute_key(column(cells, 0))
        if not chosen:
            if segments == key:
                chosen.append(index)
            continue
        if segments is not None and segments[:len(key)] != key and (len(segments) > 1 or len(key) == 1):
            break
        chosen.append(index)
    return chosen


def is_child(own: str, later: str) -> bool:
    """"๑.๑)" under "๑)", "5.5.1.1" under "5.5.1", or a relative "๑)" under an absolute "5.5.1"."""
    own_segments, later_segments = row_segments(own), row_segments(later)
    if not own_segments or not later_segments:
        return False
    if absolute_key(own) is not None and absolute_key(later) is None:
        return True
    return len(later_segments) > len(own_segments) and later_segments[:len(own_segments)] == own_segments


def item_numbers(numbers: list[str], major_item: str) -> list[str]:
    """The absolute item number of each row, for results.json `item`: "๑.๑)" under ๕.๘ → "๕.๘.๑.๑".
    The web importer only reads absolute numbers. A relative number continues the last absolute one
    ("๑)" under "5.5.1" → 5.5.1.1). A row without a number takes the one before it."""
    key = absolute_key(major_item) or []
    base = key
    thai = bool(re.search(r"[๐-๙]", major_item))
    result: list[str] = []
    for number in numbers:
        segments = absolute_key(number)
        if segments is not None and segments[:len(key)] != key:
            segments = None  # a bare "1" inside ๕.๕ is a child row, as in major_item_rows
        if segments is not None:
            base = segments
        else:
            own = row_segments(number)
            segments = base + own if own else None
        if segments is None:
            result.append(result[-1] if result else major_item)
            continue
        text = ".".join(segments)
        result.append(text.translate(str.maketrans("0123456789", "๐๑๒๓๔๕๖๗๘๙")) if thai else text)
    return result


def row_kinds(numbers: list[str]) -> list[str]:
    """major_item (the first row), sub_heading (has child rows) or content. A fact from the numbering only."""
    kinds = []
    for index, own in enumerate(numbers):
        if index == 0:
            kinds.append("major_item")
            continue
        later = next((number for number in numbers[index + 1:] if row_segments(number)), None)
        kinds.append("sub_heading" if later is not None and is_child(own, later) else "content")
    return kinds


def cited_pages(reference: str) -> list[int]:
    """Every page number after "หน้า"/"หน้าที่", ranges expanded, in order, no repeats."""
    pages: list[int] = []
    for part in PAGE_PART.findall(arabic(reference)):
        for piece in re.split(r",|และ", part):
            bounds = [int(value) for value in re.findall(r"\d+", piece)]
            if len(bounds) == 2 and re.search(r"[-–]", piece) and bounds[0] <= bounds[1]:
                numbers = range(bounds[0], bounds[1] + 1)
            else:
                numbers = bounds
            pages.extend(number for number in numbers if number not in pages)
    return pages


@functools.lru_cache(maxsize=8)
def numbered_folders(root: Path) -> tuple[tuple[Path, str], ...]:
    """Every folder under the job root whose name starts with an item number: (folder, "2.5").
    Cached for one build: the job folder doesn't change while packets are written."""
    found = []
    for directory, subdirectories, _ in os.walk(root):
        for name in subdirectories:
            match = re.match(r"\s*(\d+(?:\.\d+)*)", arabic(name))
            if match:
                found.append((Path(directory) / name, match.group(1)))
    return tuple(sorted(found))


def in_chapter(folder: Path, chapter: str) -> bool:
    return any((found := CHAPTER.search(arabic(parent.name))) and found.group(1) == chapter
               for parent in folder.parents)


def cited_folders(reference: str, root: Path) -> list[Path]:
    """Folders whose leading number is a dotted number in the reference ("2.1" never matches "2.10 …").
    When several chapters have that folder, the ones under the chapter the reference names ("ส่วนที่ 2")."""
    text = arabic(reference)
    numbers = set(re.findall(r"\d+(?:\.\d+)+", PAGE_PART.sub(" ", text)))
    matches = [folder for folder, number in numbered_folders(Path(root)) if number in numbers]
    matches = [folder for folder in matches if not any(other in folder.parents for other in matches)]
    chapter = CHAPTER.search(text)
    if chapter and len(matches) > 1:
        matches = [folder for folder in matches if in_chapter(folder, chapter.group(1))] or matches
    return matches


def row_items(number: str, major_item: str) -> set[str]:
    """The item numbers a datasheet label may give this row: "1.5" and "5.5.1.5" for ๑.๕) under ๕.๕."""
    own = row_segments(number)
    if not own:
        return set()
    items = {".".join(own)}
    key = absolute_key(major_item)
    if absolute_key(number) is None and key:
        items.add(".".join(key + own))
    return items


def column(cells: list[str], position: int) -> str:
    """SOC columns: 0 item number, 1 TOR, 2 offered text, 3 reference."""
    return cells[position] if len(cells) > position else ""


def soc_rows(soc: Path) -> list[tuple[int, int, list[str]]]:
    """(table index, 1-based row, cell texts) of every SOC table: one with a dotted item number.
    A cell merged across columns counts once, as the web importer reads it, so a full-width
    heading row has no reference."""
    rows = []
    for table_index, table in enumerate(Document(soc).tables):
        cells = []
        for row in table.rows:
            physical = {id(cell._tc): cell for cell in row.cells}.values()
            cells.append([" ".join(cell.text.split()) for cell in physical])
        if any(re.search(r"[0-9๐-๙]\.[0-9๐-๙]", re.sub(r"\s+", "", column(row, 0))) for row in cells):
            rows.extend((table_index, number, row) for number, row in enumerate(cells, start=1))
    return rows


def signal_names(cell) -> list[str]:
    """The tick-box signals of one Word cell, as short facts (inspect_word_table's cell_signals)."""
    found = cell_signals(cell)
    names = [f"checkbox {box['field']}={box['value']}" for box in found["checkboxes"]]
    names += [f"sym {sym.get('font', '')} {sym.get('char', '')}".strip() for sym in found["symbols"]]
    names += [f"drawing x{found['drawings']}"] if found["drawings"] else []
    names += [f"content control x{found['content_controls']}"] if found["content_controls"] else []
    return names + found["selected_glyphs"]


def tick_signals(soc: Path, chosen: list[tuple[int, int, list[str]]]) -> dict:
    """Comply/Better facts, so Claude needn't run inspect_word_table: whether any data row of the SOC tables
    holding the major item has a tick-box signal after the item/TOR/offer/reference columns, and each chosen
    row's signals by grid column. Header names come from the first row when it is a header (no item number);
    a cell merged down from the row above is marked, since Word shows one box over both rows."""
    tables = Document(soc).tables
    wanted = {(table_index, number) for table_index, number, _ in chosen}
    anywhere, rows = False, {}
    for table_index in sorted({table_index for table_index, _, _ in chosen}):
        table_rows = tables[table_index].rows
        first = [" ".join(cell.text.split()) for cell in table_rows[0].cells]
        has_header = not re.search(r"[0-9๐-๙]\.[0-9๐-๙]", re.sub(r"\s+", "", column(first, 0)))
        header = first if has_header else []
        for number, row in enumerate(table_rows, start=1):
            if has_header and number == 1:
                continue
            found, previous = [], None
            for position, cell in enumerate(row.cells):  # one entry per grid column
                if position < 4 or cell._tc is previous:  # the text columns, or a cell spanning columns
                    previous = cell._tc
                    continue
                previous = cell._tc
                names = signal_names(cell)
                if not names:
                    continue
                entry = {"column": position, "header": header[position] if position < len(header) else "",
                         "signals": names}
                if cell_signals(cell)["vmerge"] == "continue" or (
                        number > 1 and position < len(table_rows[number - 2].cells)
                        and table_rows[number - 2].cells[position]._tc is cell._tc):
                    entry["merged_from_row_above"] = True
                found.append(entry)
            anywhere = anywhere or bool(found)
            if found and (table_index, number) in wanted:
                rows[str(number)] = found
    return {"table_has_signals": anywhere, "rows": rows}


def relative(path: Path, root: Path) -> str:
    return path.relative_to(root).as_posix()


def page_text(page) -> str:
    lines = (" ".join(line.split()) for line in page.get_text().splitlines())
    return "\n".join(line for line in lines if line)


def printed_number(page) -> int | None:
    """The page number printed on the page: its PDF page label, else a lone number (not a year)
    in the top or bottom band."""
    label = arabic(page.get_label() or "").strip()
    if label.isdigit():
        return int(label)
    band = page.rect.height * PAGE_NUMBER_BAND
    for block in page.get_text("blocks"):
        x0, y0, x1, y1, text = block[:5]
        if y1 <= band or y0 >= page.rect.height - band:
            match = re.fullmatch(r"(?:page|หน้า|หน้าที่)?\s*(\d{1,3})(?:\s*(?:/|of|จาก)\s*\d{1,3})?",
                                 arabic(" ".join(text.split())), re.IGNORECASE)
            if match:
                return int(match.group(1))
    return None


def merge_regions(rects: list[pymupdf.Rect]) -> list[pymupdf.Rect]:
    """Overlapping crop regions become one, until none overlap."""
    regions = [pymupdf.Rect(rect) for rect in rects]
    merged = True
    while merged:
        merged = False
        for a in range(len(regions)):
            for b in range(a + 1, len(regions)):
                if regions[a].intersects(regions[b]):
                    regions[a] |= regions.pop(b)
                    merged = True
                    break
            if merged:
                break
    return sorted(regions, key=lambda region: (region.y0, region.x0))


class PdfFacts:
    """One PDF read once: page texts, printed numbers, extractor output, crops (shared by every row)."""

    def __init__(self, path: Path, root: Path, out: Path):
        self.path, self.out = path, out
        self.relative_path = relative(path, root)
        self.slug = hashlib.sha1(relative(path, root).encode("utf-8")).hexdigest()[:8]
        self.document = pymupdf.open(path)
        self.clean = content_only(self.document)
        self.page_count = self.document.page_count
        self.printed = [printed_number(page) for page in self.clean]
        self.extracted = None
        self.pages: dict[int, dict] = {}

    def close(self) -> None:
        self.clean.close()
        self.document.close()

    def page(self, number: int) -> dict:
        if number not in self.pages:
            if self.extracted is None:
                self.extracted = extract(self.path)
            self.pages[number] = self.read_page(number)
        return self.pages[number]

    def read_page(self, number: int) -> dict:
        """Write the page file once per job: several rows cite the same page. It is Markdown, not JSON:
        Claude reads it with Read, and indented JSON (plus Read's line numbers) cost about twice the
        characters. Each highlight is listed once and labels point at it by number (v1 repeated a
        highlight under every label bound to it). Returns what a row needs to point at the page."""
        text = page_text(self.clean[number - 1])
        marks = self.extracted[number - 1]
        low_text = len(re.sub(r"\s+", "", text)) < LOW_TEXT_CHARS
        visible = [mark for mark in marks["highlights"] if not mark["off_page"]]
        numbers = {tuple(mark["rect"]): index for index, mark in enumerate(visible, start=1)}
        labels = [{"item": item, "label": block["label"], "status": block["status"],
                   "highlights": [numbers[tuple(entry["rect"])] for entry in block["evidence"]
                                  if tuple(entry["rect"]) in numbers]}
                  for item, blocks in marks["evidence_blocks"].items() for block in blocks]
        unlabeled = [numbers[tuple(entry["rect"])] for entry in marks["unlabeled_highlights"]
                     if tuple(entry["rect"]) in numbers]
        summary = {
            "pdf_page": number,
            "printed_page": self.printed[number - 1],
            "low_text": low_text,
            "page_file": f"pages/{self.slug}-p{number}.md",
            "crops": self.crops(number, marks) if low_text else [],
        }
        printed = f", เลขหน้าที่พิมพ์ {summary['printed_page']}" if summary["printed_page"] not in (None, number) else ""
        lines = [f"# {self.relative_path} หน้า PDF {number}{printed}"]
        if low_text:
            lines.append(f"ข้อความน้อย (หน้าภาพ): ต้อง Read crop ด้วย: {', '.join(summary['crops'])}")
        lines.append("## Highlight")
        lines += [f"H{index}: {mark['text']}" for index, mark in enumerate(visible, start=1)] or ["(ไม่มี)"]
        lines.append("## ป้ายเลขข้อ (ป้าย → Highlight ที่ผูก)")
        lines += [f"- {label['label']} | item {label['item']} | {label['status']} | "
                  + (", ".join(f"H{index}" for index in label["highlights"]) or "ไม่มี Highlight")
                  for label in labels] or ["(ไม่มี)"]
        if unlabeled:
            lines.append("Highlight ที่ไม่มีป้าย: " + ", ".join(f"H{index}" for index in unlabeled))
        lines += ["## ข้อความทั้งหน้า", text]
        (self.out / "pages").mkdir(parents=True, exist_ok=True)
        (self.out / summary["page_file"]).write_text("\n".join(lines) + "\n", encoding="utf-8")
        return {**summary, "labels": labels}

    def label_index(self, items: set[str]) -> dict[str, list[tuple[int, str]]]:
        """Every page of the whole file with a label numbered like one of the major item's rows, so the
        P5 lookup (a label on a page the SOC didn't cite) needs no extractor run and no shell output."""
        if self.extracted is None:
            self.extracted = extract(self.path)
        found: dict[str, list[tuple[int, str]]] = {}
        for page in self.extracted:
            for item, blocks in page["evidence_blocks"].items():
                if item in items:
                    pages = found.setdefault(item, [])
                    pages.extend(entry for entry in ((page["page"], block["status"]) for block in blocks)
                                 if entry not in pages)
        return found

    def write_highlights(self) -> str:
        """The extractor output of the whole file, for validate_audit_consistency.py (Claude doesn't read it)."""
        if self.extracted is None:
            self.extracted = extract(self.path)
        name = f"hl/{self.slug}.json"
        (self.out / "hl").mkdir(parents=True, exist_ok=True)
        (self.out / name).write_text(json.dumps(self.extracted, ensure_ascii=False), encoding="utf-8")
        return name

    def crops(self, number: int, marks: dict) -> list[str]:
        """PNG crops around the page's marks (highlights and labels), or the whole page when it has none:
        an image page has no text, so without a picture the packet would hold nothing of it."""
        page = self.document[number - 1]
        padded = [pymupdf.Rect(rect.x0 - CROP_PAD, rect.y0 - CROP_PAD, rect.x1 + CROP_PAD, rect.y1 + CROP_PAD)
                  & page.rect
                  for rect in (pymupdf.Rect(entry["rect"]) for entry in marks["highlights"] + marks["labels"]
                               if not entry["off_page"])]
        (self.out / "crops").mkdir(parents=True, exist_ok=True)
        if not padded:
            name = f"crops/{self.slug}-p{number}-page.png"
            page.get_pixmap(matrix=pymupdf.Matrix(WHOLE_PAGE_ZOOM, WHOLE_PAGE_ZOOM)).save(self.out / name)
            return [name]
        names = []
        for index, region in enumerate(merge_regions(padded), start=1):
            name = f"crops/{self.slug}-p{number}-{index}.png"
            page.get_pixmap(matrix=pymupdf.Matrix(CROP_ZOOM, CROP_ZOOM), clip=region).save(self.out / name)
            names.append(name)
        return names

    def cited_pages(self, pages: list[int], row_items: set[str]) -> tuple[list[dict], list[int]]:
        """Each cited page as PDF page N, plus the PDF page whose printed number is N when that is another page.
        Also the cited numbers this file has no page for. A page carries only the labels numbered like this
        row ("1.5" or "5.5.1.5" for ๑.๕) under ๕.๕); every label stays in its page file."""
        found, missing, seen = [], [], set()
        for page_number in pages:
            targets = []
            if 1 <= page_number <= self.page_count:
                targets.append((page_number, "pdf_page"))
            targets += [(index, "printed_page") for index, printed in enumerate(self.printed, start=1)
                        if printed == page_number and index != page_number]
            if not targets:
                missing.append(page_number)
            for number, matched_by in targets:
                if number not in seen:
                    seen.add(number)
                    page = self.page(number)
                    found.append({"cited_page": page_number, "matched_by": matched_by,
                                  **{key: value for key, value in page.items() if key != "labels"},
                                  "row_labels": [{key: label[key] for key in ("item", "label", "status")}
                                                 for label in page["labels"] if label["item"] in row_items]})
        return found, missing


class PdfLibrary:
    """The job's PDFs, each opened once however many rows cite it."""

    def __init__(self, root: Path, out: Path):
        self.root, self.out = root, out
        self.pdfs: dict[Path, PdfFacts] = {}

    def candidate(self, path: Path, pages: list[int], row_items: set[str] = frozenset()) -> dict:
        entry = {"file": path.name, "folder": relative(path.parent, self.root), "path": relative(path, self.root)}
        if path.suffix.lower() != ".pdf":
            return {**entry, "note": "not a PDF: no page facts"}
        try:
            if path not in self.pdfs:
                self.pdfs[path] = PdfFacts(path, self.root, self.out)
            facts = self.pdfs[path]
            found, missing = facts.cited_pages(pages, row_items)
        except Exception as error:  # a broken or encrypted file is a fact for Claude, not a reason to stop
            return {**entry, "error": f"{type(error).__name__}: {error}"}
        entry.update({"page_count": facts.page_count, "pages": found})
        if missing:
            entry["pages_not_in_file"] = missing
        return entry

    def close(self) -> None:
        for facts in self.pdfs.values():
            facts.close()


def is_document(path: Path) -> bool:
    return path.suffix.lower() in DOCUMENT_EXTENSIONS and not path.name.startswith("~$")


def folder_files(folder: Path) -> list[Path]:
    return sorted(path for path in folder.rglob("*") if path.is_file() and is_document(path))


def first_page_text(path: Path) -> dict:
    try:
        with pymupdf.open(path) as document, content_only(document) as clean:
            text = page_text(clean[0]) if clean.page_count else ""
            entry = {"page_count": document.page_count}
    except Exception as error:
        return {"error": f"{type(error).__name__}: {error}", "first_page_text": ""}
    entry["first_page_text"] = text[:FIRST_PAGE_TEXT_MAX]
    if len(text) > FIRST_PAGE_TEXT_MAX:
        entry["first_page_text_truncated"] = True
    return entry


def other_documents(root: Path, soc: Path, datasheet_folders: list[Path]) -> list[dict]:
    """Every document that is not under a cited datasheet folder, not the SOC (or its .doc twin), not the TOR."""
    documents = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or not is_document(path):
            continue
        if any(folder in path.parents for folder in datasheet_folders):
            continue
        if path.parent == soc.parent and path.stem == soc.stem:
            continue
        if TOR_PART.search(relative(path, root)):
            continue
        entry = {"file": path.name, "folder": relative(path.parent, root)}
        if path.suffix.lower() == ".pdf":
            entry.update(first_page_text(path))
        else:
            entry["note"] = "not a PDF: no first-page text"
        documents.append(entry)
    return documents


def build(soc: Path, major_item: str, root: Path, out: Path) -> dict:
    """Write job.json (for scripts), job.md and pages/*.md (for Claude), hl/*.json (for the validator)
    and crops/*.png into out; return the packet size summary."""
    soc, root, out = Path(soc).resolve(), Path(root).resolve(), Path(out)
    rows = soc_rows(soc)
    indexes = major_item_rows([cells for _, _, cells in rows], major_item)
    if not indexes:
        raise ValueError(f"major item {major_item} not found in {soc.name}")
    chosen = [rows[index] for index in indexes]
    kinds = row_kinds([column(cells, 0) for _, _, cells in chosen])
    absolute = item_numbers([column(cells, 0) for _, _, cells in chosen], major_item)

    for folder in ("rows", "pages", "crops", "hl"):  # a rerun into the same folder leaves no stale files
        shutil.rmtree(out / folder, ignore_errors=True)
    out.mkdir(parents=True, exist_ok=True)
    library = PdfLibrary(root, out)
    job_rows = []
    page_index: dict[str, dict] = {}  # page file → the rows citing it, so Claude can check rows grouped by page
    wanted_items: set[str] = set()
    try:
        for (table_index, number, cells), kind, item_number in zip(chosen, kinds, absolute):
            reference = column(cells, 3)
            pages = cited_pages(reference)
            folders = cited_folders(reference, root)
            items = row_items(column(cells, 0), major_item)
            wanted_items |= items
            row = {
                "table_index": table_index,
                "row": number,
                "item": column(cells, 0),
                "item_number": item_number,
                "kind": kind,
                "tor_text": column(cells, 1),
                "offered_text": column(cells, 2),
                "reference": reference,
                "reference_folders": [relative(folder, root) for folder in folders],
                "cited_pages": pages,
                "candidates": [library.candidate(path, pages, items)
                               for folder in folders for path in folder_files(folder)],
            }
            job_rows.append(row)
            for candidate in row["candidates"]:
                for page in candidate.get("pages", []):
                    entry = page_index.setdefault(page["page_file"], {
                        "page_file": page["page_file"], "file": candidate["file"], "pdf_page": page["pdf_page"],
                        "low_text": page["low_text"], "crops": page["crops"], "rows": []})
                    if number not in entry["rows"]:
                        entry["rows"].append(number)
        files = []
        for path, facts in library.pdfs.items():
            files.append({"file": path.name, "path": facts.relative_path, "page_count": facts.page_count,
                          "highlights_file": facts.write_highlights(),
                          "label_index": facts.label_index(wanted_items)})
    finally:
        library.close()

    datasheet_folders = sorted({folder for _, _, cells in rows for folder in cited_folders(column(cells, 3), root)})
    job = {
        "builder": "build_evidence_packet v2",
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "soc": relative(soc, root) if root in soc.parents else soc.name,
        "major_item": major_item,
        "rows": job_rows,
        "page_index": list(page_index.values()),
        "files": files,
        "other_documents": other_documents(root, soc, datasheet_folders),
        "tick_signals": tick_signals(soc, chosen),
    }
    (out / "job.json").write_text(json.dumps(job, ensure_ascii=False), encoding="utf-8")
    (out / "job.md").write_text(job_markdown(job), encoding="utf-8")
    return size_summary(out, len(job_rows))


def job_markdown(job: dict) -> str:
    """What Claude reads first, in one file: the rows, the pages to read, the whole-file label index (P5),
    the validator's highlight files and the other documents. Facts only."""
    ids = {entry["path"]: f"F{index}" for index, entry in enumerate(job["files"], start=1)}
    ids_by_name = {entry["file"]: ids[entry["path"]] for entry in job["files"]}
    lines = [
        f"# Evidence packet ข้อ {job['major_item']} (ข้อเท็จจริงเท่านั้น ไม่มีผลตัดสิน)",
        f"SOC: {job['soc']}",
        "ต้อง Read ไฟล์หน้า (pages/*.md) ของทุกหน้าที่แถวอ้าง ก่อนตัดสินแถวนั้น ป้ายในส่วนแถวเป็นแค่ตัวชี้"
        " และห้ามสรุป \"ไม่พบ\" จาก packet อย่างเดียว",
        "", "## ไฟล์ PDF ที่ถูกอ้าง",
    ]
    lines += [f"- {ids[entry['path']]} = {entry['path']} ({entry['page_count']} หน้า)" for entry in job["files"]]
    lines += ["", "## แถว (item = เลขข้อเต็ม ใช้เป็น `item` ใน results.json)"]
    for row in job["rows"]:
        lines.append(f"### แถว {row['row']} | item {row['item_number']} | ในตาราง \"{row['item']}\" | {row['kind']}")
        lines.append(f"TOR: {row['tor_text']}")
        lines.append("ข้อเสนอ: " + ("(เหมือน TOR ทุกตัวอักษร)" if row["offered_text"] == row["tor_text"]
                                     else row["offered_text"]))
        lines.append(f"อ้างอิง: {row['reference'] or '(ว่าง)'}")
        if row["reference"] and not row["candidates"]:
            lines.append("ไฟล์ในโฟลเดอร์ที่อ้าง: ไม่พบ (ตรวจรายชื่อไฟล์เองก่อนสรุปว่าขาด)")
        for candidate in row["candidates"]:
            name = ids_by_name.get(candidate["file"], candidate["path"])
            if "error" in candidate or "note" in candidate:
                lines.append(f"- {candidate['path']}: {candidate.get('error') or candidate['note']}")
                continue
            pages = [f"หน้า {page['pdf_page']} → {page['page_file']}"
                     + (f" (อ้างหน้า {page['cited_page']} ตรงกับเลขหน้าที่พิมพ์)" if page["matched_by"] == "printed_page" else "")
                     + (" ป้ายของแถว: " + "; ".join(dict.fromkeys(f"{label['label']} {label['status']}" for label in page["row_labels"]))
                        if page["row_labels"] else " ไม่มีป้ายของแถว")
                     for page in candidate["pages"]]
            missing = f" | ไม่มีหน้า {', '.join(map(str, candidate['pages_not_in_file']))} ในไฟล์" if candidate.get("pages_not_in_file") else ""
            lines.append(f"- {name}: " + ("; ".join(pages) if pages else "ไม่มีหน้าที่อ้าง") + missing)
    lines += ["", "## ช่อง Comply/Better (ไม่ต้องรัน inspect_word_table.py)"]
    ticks = job["tick_signals"]
    if not ticks["table_has_signals"]:
        lines.append("ไม่พบช่องติ๊กในตาราง SOC (ไม่มี checkbox, w:sym, สัญลักษณ์ติ๊ก, drawing หรือ content control ในแถวใด)"
                     " → ทุกแถว declared_status: not_selected, declared_status_check: not_applicable")
    else:
        for number, found in ticks["rows"].items():
            lines.append(f"- แถว {number}: " + "; ".join(
                f"คอลัมน์ {cell['column'] + 1} \"{cell['header']}\" {', '.join(cell['signals'])}"
                + (" (เซลล์รวมกับแถวบน)" if cell.get("merged_from_row_above") else "") for cell in found))
        silent = [str(row["row"]) for row in job["rows"] if str(row["row"]) not in ticks["rows"]]
        if silent:
            lines.append(f"- ไม่มีสัญญาณ: แถว {', '.join(silent)}")
    lines += ["", "## หน้าที่ต้อง Read (ไฟล์หน้า → แถวที่อ้าง)"]
    for page in job["page_index"]:
        crops = f" + crop {', '.join(page['crops'])}" if page["crops"] else ""
        lines.append(f"- {page['page_file']} ({ids_by_name.get(page['file'], page['file'])} หน้า {page['pdf_page']}){crops}:"
                     f" แถว {', '.join(map(str, page['rows']))}")
    lines += ["", "## ป้ายเลขข้อทั้งไฟล์ (สำหรับ P5: หาป้ายของแถวบนหน้าที่ไม่ได้อ้าง)"]
    for entry in job["files"]:
        found = entry["label_index"]
        lines.append(f"- {ids[entry['path']]}: " + ("; ".join(
            f"{item} → " + ", ".join(f"หน้า {page} {status}" for page, status in pages)
            for item, pages in sorted(found.items(), key=lambda pair: [int(part) for part in pair[0].split(".")]))
            if found else "ไม่มีป้ายเลขข้อของข้อนี้"))
    lines += ["", "## ไฟล์ Highlight สำหรับ validate_audit_consistency.py (ไม่ต้องอ่าน)"]
    lines += [f"- \"{entry['file']}=out/packet/{entry['highlights_file']}\"" for entry in job["files"]]
    lines += ["", "## เอกสารอื่นในชุด (P4: ข้ออ้างเรื่องสิทธิ์)"]
    for document in job["other_documents"]:
        detail = document.get("error") or document.get("note") or " ".join(document.get("first_page_text", "").split())
        lines.append(f"- {document['folder']}/{document['file']}: {detail}")
    return "\n".join(lines) + "\n"


def size_summary(out: Path, packets: int) -> dict:
    """What Claude reads (job.md, pages/*.md, crops): characters, and rough tokens. Text: characters / 3
    (Thai and English mixed). Images: pixels / 750."""
    texts = [out / "job.md", *sorted((out / "pages").glob("*.md"))]
    characters = sum(len(path.read_text(encoding="utf-8")) for path in texts)
    crops = sorted((out / "crops").glob("*.png")) if (out / "crops").exists() else []
    image_tokens = 0
    for path in crops:
        pixmap = pymupdf.Pixmap(str(path))
        scale = min(1.0, IMAGE_MAX_EDGE / max(pixmap.width, pixmap.height))
        image_tokens += round(pixmap.width * scale * pixmap.height * scale / IMAGE_PIXELS_PER_TOKEN)
    return {
        "packets": packets,
        "pages": len(texts) - 1,
        "read_characters": characters,
        "crops": len(crops),
        "crop_bytes": sum(path.stat().st_size for path in crops),
        "rough_tokens_text": characters // 3,
        "rough_tokens_images": image_tokens,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Build evidence packets (facts only) for one major item of a Word SOC")
    parser.add_argument("soc_docx", type=Path)
    parser.add_argument("major_item", help='item number as the SOC writes it, e.g. "๕.๕" or "5.5"')
    parser.add_argument("job_folder", type=Path, help="the job's document folder (datasheets, letters, TOR)")
    parser.add_argument("output_dir", type=Path)
    args = parser.parse_args()
    try:
        summary = build(args.soc_docx, args.major_item, args.job_folder, args.output_dir)
    except ValueError as error:
        raise SystemExit(str(error)) from error
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
