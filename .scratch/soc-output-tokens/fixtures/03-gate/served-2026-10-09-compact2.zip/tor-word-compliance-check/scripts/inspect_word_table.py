from __future__ import annotations

import argparse
import json
from pathlib import Path

from docx import Document
from docx.oxml.ns import qn


CHECKED_VALUES = {"1", "true", "on", "checked"}
CHECK_GLYPHS = {"☒", "☑", "✓", "✔", "■", "●"}


def local_name(element) -> str:
    return element.tag.rsplit("}", 1)[-1]


def cell_signals(cell) -> dict:
    root = cell._tc
    grid_span = root.find(qn("w:tcPr") + "/" + qn("w:gridSpan"))
    vmerge = root.find(qn("w:tcPr") + "/" + qn("w:vMerge"))
    checkboxes = []
    symbols = []
    drawings = 0
    content_controls = 0
    for element in root.iter():
        name = local_name(element)
        if name in {"checked", "default"}:
            value = next((value for key, value in element.attrib.items() if key.endswith("}val")), "")
            checkboxes.append({"field": name, "value": value,
                               "selected": value.lower() in CHECKED_VALUES})
        elif name == "sym":
            symbols.append({key.rsplit("}", 1)[-1]: value for key, value in element.attrib.items()})
        elif name in {"drawing", "pict", "object"}:
            drawings += 1
        elif name == "sdt":
            content_controls += 1
    text = " ".join(cell.text.split())
    return {
        "text": text,
        "grid_span": int(grid_span.get(qn("w:val"), "1")) if grid_span is not None else 1,
        "vmerge": (vmerge.get(qn("w:val"), "continue") if vmerge is not None else None),
        "checkboxes": checkboxes,
        "symbols": symbols,
        "drawings": drawings,
        "content_controls": content_controls,
        "selected_glyphs": [glyph for glyph in CHECK_GLYPHS if glyph in text],
    }


def inspect(docx_path: Path, table_index: int) -> dict:
    document = Document(docx_path)
    if not 0 <= table_index < len(document.tables):
        raise ValueError(f"table_index must be between 0 and {len(document.tables) - 1}")
    table = document.tables[table_index]
    rows = []
    for row_index, row in enumerate(table.rows):
        tc_order: dict[int, int] = {}
        cells = []
        for column_index, cell in enumerate(row.cells):
            tc_key = id(cell._tc)
            if tc_key not in tc_order:
                tc_order[tc_key] = len(tc_order)
            signals = cell_signals(cell)
            signals.update({"column": column_index, "merged_cell_id": tc_order[tc_key]})
            cells.append(signals)
        rows.append({
            "row": row_index + 1,
            "physical_cell_count": len(tc_order),
            "logical_column_count": len(row.cells),
            "is_merged_across_content": len({cell["merged_cell_id"] for cell in cells[1:]}) == 1,
            "cells": cells,
        })
    return {"table_index": table_index, "rows": rows}


def main() -> None:
    parser = argparse.ArgumentParser(description="Inspect merged cells and form/control signals in a Word table")
    parser.add_argument("input_docx", type=Path)
    parser.add_argument("output_json", type=Path)
    parser.add_argument("--table-index", type=int, default=0)
    args = parser.parse_args()
    data = inspect(args.input_docx, args.table_index)
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"table_index": data["table_index"], "rows": len(data["rows"]),
                      "merged_rows": sum(row["is_merged_across_content"] for row in data["rows"])},
                     ensure_ascii=False))


if __name__ == "__main__":
    main()
