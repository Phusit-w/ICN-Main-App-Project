"""List the evidence-packet pages a packet-mode run never opened, with the rows that cite them.

Reads the packet's job.json (page_index) and the run's headless log (`claude -p --output-format stream-json`,
one JSON event per line). A page counts as opened only when Claude called the Read tool on its page file:
row_labels in a row packet is a pointer, and a row judged from it alone can miss evidence that sits on the
page without a highlight (case ๑.๓). A page file only named in a shell command is listed apart, since a
script can print part of it. Low-text pages also need their crops read.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

SHELL_TOOLS = {"Bash", "PowerShell"}


def path_key(value: str) -> str:
    return value.strip().replace("\\", "/").lower()


def tool_calls(log_lines: list[str]) -> list[tuple[str, dict]]:
    """(tool name, input) of every tool call in a stream-json log; lines that aren't JSON events are skipped."""
    calls = []
    for line in log_lines:
        try:
            event = json.loads(line)
        except ValueError:
            continue
        if not isinstance(event, dict) or event.get("type") != "assistant":
            continue
        for block in (event.get("message") or {}).get("content") or []:
            if isinstance(block, dict) and block.get("type") == "tool_use":
                calls.append((block.get("name") or "", block.get("input") or {}))
    return calls


def opened(name: str, read_paths: list[str]) -> bool:
    """Read on this packet file: page_file is relative to the packet folder ("pages/x-p3.json")."""
    key = path_key(name)
    return any(path == key or path.endswith("/" + key) for path in read_paths)


def check(job: dict, log_lines: list[str]) -> dict:
    calls = tool_calls(log_lines)
    read_paths = [path_key(str(arguments.get("file_path") or "")) for tool, arguments in calls if tool == "Read"]
    commands = [path_key(str(arguments.get("command") or "")) for tool, arguments in calls if tool in SHELL_TOOLS]
    items = {row["row"]: row["item"] for row in job.get("rows", [])}

    not_read, shell_only, crops_not_read = [], [], []
    for page in job.get("page_index", []):
        where = {"page_file": page["page_file"], "file": page["file"], "pdf_page": page["pdf_page"],
                 "rows": [{"row": row, "item": items.get(row, "")} for row in page["rows"]]}
        if not opened(page["page_file"], read_paths):
            name = path_key(page["page_file"]).rsplit("/", 1)[-1]
            (shell_only if any(name in command for command in commands) else not_read).append(where)
        missing_crops = [crop for crop in page.get("crops", []) if not opened(crop, read_paths)]
        if missing_crops:
            crops_not_read.append({**where, "crops": missing_crops})
    return {
        "pages": len(job.get("page_index", [])),
        "read_calls": len(read_paths),
        "not_read": not_read,
        "shell_only": shell_only,
        "crops_not_read": crops_not_read,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="List packet pages a packet-mode run never opened with Read")
    parser.add_argument("packet_dir", type=Path, help="the folder build_evidence_packet.py wrote (has job.json)")
    parser.add_argument("logs", type=Path, nargs="+", help="stream-json log(s) of the run, resumed sessions too")
    args = parser.parse_args()
    job = json.loads((args.packet_dir / "job.json").read_text(encoding="utf-8"))
    lines = [line for log in args.logs for line in log.read_text(encoding="utf-8-sig").splitlines()]
    report = check(job, lines)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(2 if report["not_read"] or report["shell_only"] or report["crops_not_read"] else 0)


if __name__ == "__main__":
    main()
