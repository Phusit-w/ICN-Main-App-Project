from __future__ import annotations

import argparse
import json
import re
from pathlib import Path, PurePosixPath

THAI_DIGITS = str.maketrans("๐๑๒๓๔๕๖๗๘๙", "0123456789")
ITEM_NUMBER = re.compile(r"^\d+(?:\.\d+)*\.?$")  # what the web importer accepts as `item`


def normalize_item(value: object) -> str:
    return str(value or "").translate(THAI_DIGITS).strip()


def numbers(value: object) -> set[str]:
    return set(re.findall(r"(?<![A-Za-z])[-+]?\d+(?:\.\d+)?", str(value or "").translate(THAI_DIGITS)))


def measurements(value: object) -> set[tuple[str, str]]:
    text = str(value or "").translate(THAI_DIGITS).lower()
    pairs = re.findall(r"([-+]?\d+(?:\.\d+)?)\s*(million pixels?|mp|lux|fps|dbm?|%|ghz|mhz|khz|hz)", text)
    normalized = set()
    for number, unit in pairs:
        unit = "million pixels" if unit.startswith("million pixel") or unit == "mp" else unit
        normalized.add((number, unit))
    return normalized


def dimensions(value: object) -> set[tuple[int, int]]:
    """Extract ordered resolution pairs without treating unrelated scalars as dimensions."""
    text = str(value or "").translate(THAI_DIGITS).lower()
    pattern = r"(\d{2,6})\s*(?:\(\s*h\s*\))?\s*[x×*]\s*(\d{2,6})\s*(?:\(\s*v\s*\))?"
    return {(int(width), int(height)) for width, height in re.findall(pattern, text, flags=re.I)}


def is_resolution_context(value: object) -> bool:
    text = str(value or "").lower()
    return any(token in text for token in ("resolution", "pixel", "pixels", "px", "ความละเอียด", "พิกเซล"))


# "1.3.1" is an item number, not page 1.
PAGE_RUN = r"(\d++)(?!\.\d)(?:\s*(?:-|–|to|ถึง)\s*(\d++)(?!\.\d))?"
PAGE_START = re.compile(r"(?:(?<![a-z])pages?|(?<![a-z])pp?\.|หน้า(?:ที่)?)\s*" + PAGE_RUN)
# A further listed page must not run into an English word: "Page 4-8, 7 Appendix" is pages 4-8 only.
PAGE_NEXT = re.compile(r"\s*(?:,|และ|and|&)\s*" + PAGE_RUN + r"(?!\s*(?!(?:and|to)\b)[a-z])")


def pages(value: object) -> list[int]:
    """Pages cited after "page"/"หน้า" (English or Thai digits), e.g. "2.5 หน้า ๑, ๓" -> [1, 3]."""
    text = str(value or "").translate(THAI_DIGITS).lower()
    found: list[int] = []

    def add(match: re.Match) -> None:
        first = int(match.group(1))
        last = int(match.group(2)) if match.group(2) else first
        found.extend(range(first, last + 1) if last >= first else (first, last))

    for start in PAGE_START.finditer(text):
        add(start)
        position = start.end()
        while more := PAGE_NEXT.match(text, position):
            add(more)
            position = more.end()
    return list(dict.fromkeys(found))


# Highlight pages by page number, per evidence file (None: the one file of a one-file run).
HighlightsByFile = dict[str | None, dict[int, dict]]


def file_key(name: str) -> str:
    """A file path as rows and specs may write it: any slash, any case."""
    return name.strip().replace("\\", "/").lower().removeprefix("./")


def same_file(spec_key: str, row_key: str) -> bool:
    """The row names this file, by its full path or by a path tail ("TC22.pdf", "1./Datasheet.pdf").
    A row name without an extension ("TC22") matches the file of that name with any extension."""
    if not PurePosixPath(row_key).suffix:
        spec_key = str(PurePosixPath(spec_key).with_suffix(""))
    return spec_key == row_key or spec_key.endswith("/" + row_key) or row_key.endswith("/" + spec_key)


def load_highlights(specs: list[str]) -> HighlightsByFile:
    """Each spec is "FILE=highlights.json" (FILE as rows name it in reference_file) or a bare path for a one-file run."""
    sources: dict[str | None, str] = {}
    for spec in specs:
        name, separator, path = spec.partition("=")
        key, source = (file_key(name), path) if separator else (None, spec)
        if key in sources:
            raise ValueError(f"highlights for {name if separator else 'a bare path'} given twice")
        sources[key] = source
    if None in sources and len(sources) > 1:
        raise ValueError("with several highlights files give each as FILE=highlights.json")
    return {key: {page["page"]: page for page in json.loads(Path(source).read_text(encoding="utf-8"))}
            for key, source in sources.items()}


def resolve(result: dict, highlights: HighlightsByFile) -> tuple[dict[int, dict] | None, str]:
    """The highlight pages of the file this row uses, or None and why not."""
    name = str(result.get("reference_file") or "").strip()
    if None in highlights:  # a one-file run: every row uses that file
        return highlights[None], ""
    if not name:
        return (next(iter(highlights.values())), "") if len(highlights) == 1 else (None, "no reference_file")
    matches = [pages_by_number for key, pages_by_number in highlights.items() if same_file(key, file_key(name))]
    if len(matches) > 1:
        return None, f"{name} matches several highlights files"
    return (matches[0], "") if matches else (None, f"no highlights for {name}")


def blocks_for(result: dict, pages_by_number: dict[int, dict]) -> list[dict]:
    item = normalize_item(result.get("item"))
    blocks = []
    for page_number in pages(result.get("reference")):
        blocks.extend(pages_by_number.get(page_number, {}).get("evidence_blocks", {}).get(item, []))
    return blocks


def validate(results_path: Path, highlights: HighlightsByFile) -> tuple[list[dict], list[dict]]:
    """Issues (contradictions to review) and the rows skipped because their file has no highlights."""
    results = json.loads(results_path.read_text(encoding="utf-8"))["results"]
    issues, skipped = [], []
    for result in results:
        item = normalize_item(result.get("item"))
        if not ITEM_NUMBER.match(re.sub(r"\s+", "", item)):
            # The web importer rejects the whole run over one: "๑)" must be written "๕.๘.๑".
            issues.append({"row": result.get("row"), "item": item, "rule": "item_is_not_an_absolute_item_number"})
        pages_by_number, reason = resolve(result, highlights)
        if pages_by_number is None:
            skipped.append({"row": result.get("row"), "item": item, "reason": reason})
            continue
        where = {"row": result.get("row"), "item": item, "file": result.get("reference_file")}
        confident = [block for block in blocks_for(result, pages_by_number) if block.get("status") == "confident"]
        if confident and result.get("item_label_check") in {"not_found", "unverifiable"}:
            issues.append({**where, "rule": "confident_block_but_item_label_failed"})
        block_text = " ".join(e.get("text", "") for block in confident for e in block.get("evidence", []))
        verified_measurements = measurements(result.get("verified_value"))
        if (confident and verified_measurements and verified_measurements <= measurements(block_text)
                and result.get("reference_check") == "mismatch"):
            issues.append({**where, "rule": "verified_values_in_confident_block_but_reference_mismatch",
                           "values": sorted(verified_measurements)})
        verified_dimensions = dimensions(result.get("verified_value"))
        if (confident and is_resolution_context(result.get("verified_value")) and verified_dimensions
                and verified_dimensions <= dimensions(block_text)
                and result.get("reference_check") == "mismatch"):
            issues.append({**where, "rule": "resolution_pair_in_confident_block_but_reference_mismatch",
                           "values": sorted(verified_dimensions)})
    return issues, skipped


def main() -> None:
    parser = argparse.ArgumentParser(description="Flag audit results that contradict confident item-level evidence blocks")
    parser.add_argument("results_json", type=Path)
    parser.add_argument("highlights", nargs="+", metavar="[FILE=]HIGHLIGHTS_JSON",
                        help="one per datasheet, FILE matching the rows' reference_file; a bare path for a one-file run")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    issues, skipped = validate(args.results_json, load_highlights(args.highlights))
    payload = {"issue_count": len(issues), "issues": issues, "skipped": skipped}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False))
    raise SystemExit(2 if issues else 0)


if __name__ == "__main__":
    main()
