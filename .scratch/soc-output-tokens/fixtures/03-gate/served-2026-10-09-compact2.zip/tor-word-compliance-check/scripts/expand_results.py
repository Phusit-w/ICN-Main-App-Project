"""Expand Compact Results (what Claude writes in the evidence-packet flow) into a full results.json.

Claude writes only its judgements and explanations per row. This script fills in what the evidence
packet already knows (job.json): item, the raw reference, reference_file when the row has one
candidate file, declared status when the SOC has no tick boxes, tor_claim_results, and standard
wording for rows that pass. It never judges: a judgement Claude left out is an error naming the row.

    python scripts/expand_results.py compact.json out/packet/job.json results.json [--rows 93,95]
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

PASS_TEXT = "ผ่าน"
# A row passes when every axis is fine; only then does the script write standard wording.
# partial_visible and better pass too, but Claude still writes what their rules demand.
PASSING = {
    "reference_check": {"match"},
    "item_label_check": {"match", "not_applicable"},
    "highlight_check": {"complete", "partial_visible", "not_applicable"},
    "evidence_support": {"fully_supported"},
    "tor_decision": {"compliant", "better", "not_applicable"},
}
DECIDED = {"compliant", "better", "non_compliant", "mixed"}  # rows whose basis must quote the datasheet (rule 8)
JUDGEMENTS = (*PASSING, "confidence", "tor_decision_basis", "declared_status", "declared_status_check")
EXPLANATIONS = ("reference_detail", "highlight_evidence", "evidence_detail", "detail", "key_issue")


class ExpandError(ValueError):
    def __init__(self, errors: list[str]):
        super().__init__("\n".join(errors))
        self.errors = errors


def passes(row: dict) -> bool:
    return all(row.get(field) in allowed for field, allowed in PASSING.items())


def arabic(text: str) -> str:
    return text.translate(str.maketrans("๐๑๒๓๔๕๖๗๘๙", "0123456789"))


def folder_number(candidate: dict) -> str | None:
    match = re.match(r"\s*(\d+)[.)\s]", arabic(candidate.get("folder", "").replace("\\", "/").rsplit("/", 1)[-1]))
    return match.group(1) if match else None


def pick_reason(chosen: str, candidates: list[dict], item_number: str, major_item: str) -> str | None:
    """Why this file among several, when the packet's facts alone show it (SKILL.md step 0, rules 1 and 2)."""
    segments = arabic(item_number).split(".")
    sub_item = segments[len(arabic(major_item).split("."))] if len(segments) > len(major_item.split(".")) else None
    by_folder = [candidate["file"] for candidate in candidates if sub_item and folder_number(candidate) == sub_item]
    if by_folder == [chosen]:
        return f"เลือกไฟล์ตามเลขโฟลเดอร์ย่อย {sub_item}."
    by_label = [candidate["file"] for candidate in candidates
                if any(page["row_labels"] for page in candidate.get("pages", []))]
    if by_label == [chosen]:
        return "เลือกไฟล์ที่มีป้ายเลขข้อของแถว"
    return None


def expand_row(given: dict, facts: dict, ticks: dict, major_item: str, errors: list[str]) -> dict:
    files = [candidate["file"] for candidate in facts["candidates"]]
    row = {
        "row": facts["row"],
        "item": facts["item_number"],
        "reference": facts["reference"],
        "tor_claim_results": [],
        "verified_value": "-",
        "tor_threshold": "-",
    }
    if len(files) == 1:
        row["reference_file"] = files[0]
    if not ticks["table_has_signals"]:
        row["declared_status"] = "not_selected"
        row["declared_status_check"] = "not_applicable"
    if facts["kind"] == "content":
        row["heading_title_check"] = "not_applicable"
    row.update(given)
    row["item"], row["reference"] = facts["item_number"], facts["reference"]

    if passes(row):
        pages = ", ".join(map(str, facts.get("cited_pages") or []))
        if row.get("reference_file"):
            standard = row["reference_file"] + (f" หน้า {pages}" if pages else "") + " ตรงหัวข้อ"
            if len(files) > 1:  # P5: say how the file was picked; only when the facts show it
                reason = pick_reason(row["reference_file"], facts["candidates"], facts["item_number"], major_item)
                standard = f"{standard} ({reason})" if reason else None
            if standard:
                row.setdefault("reference_detail", standard)
        row.setdefault("content_relevance", "related")
        if row["highlight_check"] == "complete":  # partial_visible: Claude says which words, seen where (rule 11)
            row.setdefault("highlight_evidence", "Highlight ครอบข้อความที่ตรวจครบ")
        elif row["highlight_check"] == "not_applicable":
            row.setdefault("highlight_evidence", "-")
        if row["tor_decision"] == "not_applicable":
            row.setdefault("tor_decision_basis", "-" if facts["kind"] == "content" else "แถวหัวข้อ ไม่มีเกณฑ์")
        row.setdefault("evidence_detail", "-")
        if row["tor_decision"] == "better":
            row.setdefault("detail", "ดีกว่า")
            row.setdefault("key_issue", row.get("tor_decision_basis"))
        else:
            row.setdefault("detail", PASS_TEXT)
            row.setdefault("key_issue", PASS_TEXT)
    required = (JUDGEMENTS + EXPLANATIONS + (("reference_file",) if files and facts.get("cited_pages") else ())
                + (() if facts["kind"] == "content" else ("heading_title_check",)))
    missing = [field for field in required if row.get(field) in (None, "")]
    if missing:
        errors.append(f"แถว {facts['row']}: ต้องเขียน {', '.join(missing)}")
    basis = str(row.get("tor_decision_basis") or "")
    if row.get("tor_decision") in DECIDED and basis and not ("หน้า" in basis and "→" in basis):
        errors.append(f"แถว {facts['row']}: tor_decision_basis ต้องเป็น \"เงื่อนไข: ค่าใน DS (หน้า X) → ผล\""
                      f" ทีละเงื่อนไข แม้ข้อเสนอคัดลอก TOR (ได้ {basis[:40]!r})")
    return row


def expand(compact: dict, job: dict, only_rows: set[int] | None = None) -> dict:
    """`only_rows`: a re-check of rows the reviewer picked; the results hold just those."""
    facts = {row["row"]: row for row in job["rows"] if only_rows is None or row["row"] in only_rows}
    errors: list[str] = []
    written = [given.get("row") for given in compact["results"]]
    errors += [f"แถว {number}: ไม่มีใน packet" + (" หรือไม่ได้ถูกเลือกให้ตรวจใหม่" if only_rows else "")
               for number in written if number not in facts]
    errors += [f"แถว {number}: ซ้ำ" for number in sorted({n for n in written if written.count(n) > 1}, key=str)]
    errors += [f"แถว {number}: ยังไม่มีผล" for number in facts if number not in written]
    results = [expand_row(given, facts[given["row"]], job["tick_signals"], job["major_item"], errors)
               for given in compact["results"] if given.get("row") in facts]
    if errors:
        raise ExpandError(errors)
    options = list(compact.get("options", []))
    return {**compact, "options": options + ["evidence_packet"] * ("evidence_packet" not in options), "results": results}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("compact", type=Path)
    parser.add_argument("job", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--rows", help="re-check of picked rows: the row numbers, comma-separated (e.g. 93,95)")
    args = parser.parse_args()
    compact = json.loads(args.compact.read_text(encoding="utf-8"))
    job = json.loads(args.job.read_text(encoding="utf-8"))
    try:
        only_rows = {int(number) for number in args.rows.split(",")} if args.rows else None
        results = expand(compact, job, only_rows)
    except ExpandError as error:
        print("แก้ compact แล้วรันใหม่:", *error.errors, sep="\n", file=sys.stderr)
        return 1
    args.output.write_text(json.dumps(results, ensure_ascii=False, indent=1), encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
